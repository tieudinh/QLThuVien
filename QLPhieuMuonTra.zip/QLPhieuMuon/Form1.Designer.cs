﻿namespace QLPhieuMuon
{
    partial class frmPhieuMuon
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThem = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.txtMaPhieu = new System.Windows.Forms.TextBox();
            this.txtMaDocGia = new System.Windows.Forms.TextBox();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.lblPhieu = new System.Windows.Forms.Label();
            this.lblMaDocGia = new System.Windows.Forms.Label();
            this.lblMaSach = new System.Windows.Forms.Label();
            this.lblNgayMuon = new System.Windows.Forms.Label();
            this.lblNgayPhaiTra = new System.Windows.Forms.Label();
            this.dgvBang = new System.Windows.Forms.DataGridView();
            this.txtNgayMuon = new System.Windows.Forms.TextBox();
            this.txtNgayPhaiTra = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBang)).BeginInit();
            this.SuspendLayout();
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(621, 115);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(94, 29);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Location = new System.Drawing.Point(621, 225);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(94, 29);
            this.btnCapNhat.TabIndex = 1;
            this.btnCapNhat.Text = "Cập nhật";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(621, 170);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(94, 29);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(621, 284);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(94, 29);
            this.btnThoat.TabIndex = 3;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // txtMaPhieu
            // 
            this.txtMaPhieu.Location = new System.Drawing.Point(283, 68);
            this.txtMaPhieu.Name = "txtMaPhieu";
            this.txtMaPhieu.Size = new System.Drawing.Size(250, 27);
            this.txtMaPhieu.TabIndex = 4;
            // 
            // txtMaDocGia
            // 
            this.txtMaDocGia.Location = new System.Drawing.Point(283, 117);
            this.txtMaDocGia.Name = "txtMaDocGia";
            this.txtMaDocGia.Size = new System.Drawing.Size(250, 27);
            this.txtMaDocGia.TabIndex = 5;
            // 
            // txtMaSach
            // 
            this.txtMaSach.Location = new System.Drawing.Point(283, 170);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(250, 27);
            this.txtMaSach.TabIndex = 6;
            // 
            // lblPhieu
            // 
            this.lblPhieu.AutoSize = true;
            this.lblPhieu.Location = new System.Drawing.Point(75, 75);
            this.lblPhieu.Name = "lblPhieu";
            this.lblPhieu.Size = new System.Drawing.Size(71, 20);
            this.lblPhieu.TabIndex = 9;
            this.lblPhieu.Text = "Mã phiếu";
            // 
            // lblMaDocGia
            // 
            this.lblMaDocGia.AutoSize = true;
            this.lblMaDocGia.Location = new System.Drawing.Point(75, 117);
            this.lblMaDocGia.Name = "lblMaDocGia";
            this.lblMaDocGia.Size = new System.Drawing.Size(84, 20);
            this.lblMaDocGia.TabIndex = 10;
            this.lblMaDocGia.Text = "Mã độc giả";
            // 
            // lblMaSach
            // 
            this.lblMaSach.AutoSize = true;
            this.lblMaSach.Location = new System.Drawing.Point(75, 170);
            this.lblMaSach.Name = "lblMaSach";
            this.lblMaSach.Size = new System.Drawing.Size(63, 20);
            this.lblMaSach.TabIndex = 11;
            this.lblMaSach.Text = "Mã sách";
            // 
            // lblNgayMuon
            // 
            this.lblNgayMuon.AutoSize = true;
            this.lblNgayMuon.Location = new System.Drawing.Point(75, 224);
            this.lblNgayMuon.Name = "lblNgayMuon";
            this.lblNgayMuon.Size = new System.Drawing.Size(87, 20);
            this.lblNgayMuon.TabIndex = 12;
            this.lblNgayMuon.Text = "Ngày mượn";
            // 
            // lblNgayPhaiTra
            // 
            this.lblNgayPhaiTra.AutoSize = true;
            this.lblNgayPhaiTra.Location = new System.Drawing.Point(75, 286);
            this.lblNgayPhaiTra.Name = "lblNgayPhaiTra";
            this.lblNgayPhaiTra.Size = new System.Drawing.Size(123, 20);
            this.lblNgayPhaiTra.TabIndex = 13;
            this.lblNgayPhaiTra.Text = "Ngày trả dự kiến ";
            // 
            // dgvBang
            // 
            this.dgvBang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBang.Location = new System.Drawing.Point(7, 397);
            this.dgvBang.Name = "dgvBang";
            this.dgvBang.RowHeadersWidth = 51;
            this.dgvBang.RowTemplate.Height = 29;
            this.dgvBang.Size = new System.Drawing.Size(788, 188);
            this.dgvBang.TabIndex = 17;
            this.dgvBang.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvBang_RowHeaderMouseClick);
            // 
            // txtNgayMuon
            // 
            this.txtNgayMuon.Location = new System.Drawing.Point(283, 225);
            this.txtNgayMuon.Name = "txtNgayMuon";
            this.txtNgayMuon.Size = new System.Drawing.Size(250, 27);
            this.txtNgayMuon.TabIndex = 18;
            // 
            // txtNgayPhaiTra
            // 
            this.txtNgayPhaiTra.Location = new System.Drawing.Point(283, 279);
            this.txtNgayPhaiTra.Name = "txtNgayPhaiTra";
            this.txtNgayPhaiTra.Size = new System.Drawing.Size(250, 27);
            this.txtNgayPhaiTra.TabIndex = 19;
            // 
            // frmPhieuMuon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 674);
            this.Controls.Add(this.txtNgayPhaiTra);
            this.Controls.Add(this.txtNgayMuon);
            this.Controls.Add(this.dgvBang);
            this.Controls.Add(this.lblNgayPhaiTra);
            this.Controls.Add(this.lblNgayMuon);
            this.Controls.Add(this.lblMaSach);
            this.Controls.Add(this.lblMaDocGia);
            this.Controls.Add(this.lblPhieu);
            this.Controls.Add(this.txtMaSach);
            this.Controls.Add(this.txtMaDocGia);
            this.Controls.Add(this.txtMaPhieu);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnCapNhat);
            this.Controls.Add(this.btnThem);
            this.Name = "frmPhieuMuon";
            this.Text = "Quản lý Phiếu mượn";
            this.Load += new System.EventHandler(this.frmPhieuMuon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnThem;
        private Button btnCapNhat;
        private Button btnXoa;
        private Button btnThoat;
        private TextBox txtMaPhieu;
        private TextBox txtMaDocGia;
        private TextBox txtMaSach;
        private Label lblPhieu;
        private Label lblMaDocGia;
        private Label lblMaSach;
        private Label lblNgayMuon;
        private Label lblNgayPhaiTra;
        private DateTimePicker dtpNgayTraDuKien;
        private DataGridView dgvBang;
        private TextBox txtNgayMuon;
        private TextBox txtNgayPhaiTra;
    }
}