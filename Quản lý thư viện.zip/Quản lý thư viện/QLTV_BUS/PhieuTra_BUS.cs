﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using QLTV_DTO;
using QLTV_DAO;

namespace QLTV_BUS
{
    public class PhieuTra_BUS
    {
        public static List<Class_PhieuTra> layDSPhieuTra()
        {
            return PhieuTra_DAO.layDSPhieuTra();
        }

        public static bool themPT(Class_PhieuTra pt)
        {
            try
            {
                PhieuTra_DAO.themPT(pt);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<Class_PhieuTra> timKiemPT_DocGia(string lok)
        {
            return PhieuTra_DAO.timKiemPT_DocGia(lok);
        }

        public static List<Class_PhieuTra> timKiemPT_Sach(string lok)
        {
            return PhieuTra_DAO.timKiemPT_Sach(lok);
        }
    }
}
