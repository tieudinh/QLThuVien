﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLTV_DTO;
using QLTV_DAO;

namespace QLTV_BUS
{
    public class Sach_BUS
    {
        public static List<Class_Sach> layDSSach()
        {
            return Sach_DAO.layDSSach();
        }

        public static bool themSach(Class_Sach sach)
        {
            try
            {
                Sach_DAO.themSach(sach);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool xoaSach(string ms)
        {
            try
            {
                Sach_DAO.xoaSach(ms);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool suaSach(Class_Sach sach)
        {
            try
            {
                Sach_DAO.suaSach(sach);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<Class_Sach> TimTacGia(string tacgia)
        {
            return Sach_DAO.timKiemSach_TacGia(tacgia);
        }

        public static List<Class_Sach> TimTheLoai(string theloai)
        {
            return Sach_DAO.timKiemSach_TheLoai(theloai);
        }

        public static List<Class_Sach> TimTen(string tim)
        {
            return Sach_DAO.timKiemSach_TenSach(tim);
        }

        public static List<Class_Sach> TimNhaXuatBan(string nhaXuatBan)
        {
            return Sach_DAO.timKiemSach_NXB(nhaXuatBan);
        }

        public static List<Class_Sach> TimMaSach(string maSach)
        {
            return Sach_DAO.timKiemSach_MaSach(maSach);
        }

        public static List<Class_Sach> TimTinhTrang(string tinhTrang)
        {
            return Sach_DAO.timKiemSach_TinhTrang(tinhTrang);
        }
    }
}
