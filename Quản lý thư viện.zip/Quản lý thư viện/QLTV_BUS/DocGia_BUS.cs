﻿using QLTV_DTO;
using QLTV_DAO;

namespace QLTV_BUS
{
    public class DocGia_BUS
    {
        public static List<Class_DocGia> LayDSDocGia()
        {
            return DocGia_DAO.layDSDocGia();
        }

        public static List<Class_DocGia> layTTDocGia()
        {
            return DocGia_DAO.layTTDocGia();
        }

        public static List<Class_DocGia> timKiemDG_HoTen(string lok)
        {
            return DocGia_DAO.timKiemDocGia_Ten(lok);
        }

        public static List<Class_DocGia> timKiemDG_MaDocGia(string lok)
        {
            return DocGia_DAO.timKiemDocGia_MaDocGia(lok);
        }

        public static List<Class_DocGia> timKiemDG_TenDangNhap(string lok)
        {
            return DocGia_DAO.timKiemDocGia_TenDangNhap(lok);
        }

        public static bool themDG(Class_DocGia dg)
        {
            try
            {
                DocGia_DAO.themDG(dg);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool xoaDG(string dg)
        {
            try
            {
                DocGia_DAO.xoaDG(dg);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool suaDG(Class_DocGia dg)
        {
            try
            {
                DocGia_DAO.suaDG(dg);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
