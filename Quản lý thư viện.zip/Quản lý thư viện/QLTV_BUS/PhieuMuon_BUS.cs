﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using QLTV_DTO;
using QLTV_DAO;

namespace QLTV_BUS
{
    public class PhieuMuon_BUS
    {
        public static List<Class_PhieuMuon> layDSPhieuMuon()
        {
            return PhieuMuon_DAO.layDSPhieuMuon();
        }

        public static bool themPM(Class_PhieuMuon pm)
        {
            try
            {
                PhieuMuon_DAO.themPM(pm);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool xoaPM(string lok)
        {
            try
            {
                PhieuMuon_DAO.xoaPM(lok);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool suaPM(Class_PhieuMuon pm)
        {
            try
            {
                PhieuMuon_DAO.suaPM(pm);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<Class_PhieuMuon> timKiemPM_DocGia(string lok)
        {
            return PhieuMuon_DAO.timKiemPM_DocGia(lok);
        }

        public static List<Class_PhieuMuon> timKiemPM_Sach(string lok)
        {
            return PhieuMuon_DAO.timKiemPM_Sach(lok);
        }
    }
}
