﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using QLTV_DTO;

namespace QLTV_DAO
{
    public class Sach_DAO
    {
        public static List<Class_Sach> layDSSach()
        {
            List<Class_Sach> list = new List<Class_Sach>();
            DataTable dataTable = DataProvider.TruyVan_LayDuLieu("SELECT * FROM Sach");
            foreach (DataRow dr in dataTable.Rows)
            {
                Class_Sach lh = new Class_Sach()
                {
                    MaSach = dr["MaSach"].ToString(),
                    TenSach = dr["TenSach"].ToString(),
                    TacGia = dr["TacGia"].ToString(),
                    TheLoai = dr["TheLoai"].ToString(),
                    NhaXuatBan = dr["NhaXuatBan"].ToString(),
                    TinhTrang = dr["TinhTrang"].ToString(),
                    GiaSach = int.Parse(dr["GiaSach"].ToString())
                };
                list.Add(lh);
            }
            return list;
        }

        public static void themSach(Class_Sach sach)
        {
            string sql = "insert into Sach (MaSach, TenSach, TacGia, TheLoai, NhaXuatBan, TinhTrang, GiaSach) values (@MaSach, @TenSach, @TacGia, @TheLoai, @NhaXuatBan, @TinhTrang, @GiaSach),";
            SqlParameter[] parameters = new SqlParameter[7];
            parameters[0] = new SqlParameter("MaSach", sach.MaSach);
            parameters[1] = new SqlParameter("TenSach", sach.TenSach);
            parameters[2] = new SqlParameter("TacGia", sach.TacGia);
            parameters[3] = new SqlParameter("TheLoai", sach.TheLoai);
            parameters[4] = new SqlParameter("NhaXuatBan", sach.NhaXuatBan);
            parameters[5] = new SqlParameter("TinhTrang", sach.TinhTrang);
            parameters[6] = new SqlParameter("GiaSach", SqlDbType.Int);
            parameters[6].Value = sach.GiaSach;
            DataProvider.ExcuteNonQuery(sql, CommandType.Text, parameters);
        }

        public static void xoaSach(string ms)
        {
            string query = "delete from Sach where MaSach = @MaSach";
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("MaSach", ms);
            DataProvider.ExcuteNonQuery(query, CommandType.Text, parameters);
        }

        public static void suaSach(Class_Sach sach)
        {
            string query = "update Sach set Sach.TenSach = &TenSach, Sach.TacGia = @TacGia, Sach.TheLoai = @TheLoai, Sach.NhaXuatBan = @NhaXuatBan Sach.TinhTrang = @TinhTrang, Sach.GiaSach = @GiaSach where Sach.MaSach = &MaSach";
            SqlParameter[] parameters = new SqlParameter[7];
            parameters[0] = new SqlParameter("MaSach", sach.MaSach);
            parameters[1] = new SqlParameter("TenSach", sach.TenSach);
            parameters[2] = new SqlParameter("TacGia", sach.TacGia);
            parameters[3] = new SqlParameter("TheLoai", sach.TheLoai);
            parameters[4] = new SqlParameter("NhaXuatBan", sach.NhaXuatBan);
            parameters[5] = new SqlParameter("TinhTrang", sach.TinhTrang);
            parameters[6] = new SqlParameter("GiaSach", SqlDbType.Int);
            parameters[6].Value = sach.GiaSach;
            DataProvider.ExcuteNonQuery(query, CommandType.Text, parameters);
        }

        public static List<Class_Sach> timKiemSach_TenSach(string lok)
        {
            List<Class_Sach> dsS = new List<Class_Sach>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM Sach WHERE TenSach LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_Sach sach = new Class_Sach()
                {
                    MaSach = dr["MaSach"].ToString(),
                    TenSach = dr["TenSach"].ToString(),
                    TacGia = dr["TacGia"].ToString(),
                    TheLoai = dr["TheLoai"].ToString(),
                    NhaXuatBan = dr["NhaXuatBan"].ToString(),
                    GiaSach = int.Parse(dr["GiaSach"].ToString()),
                    TinhTrang = dr["TinhTrang"].ToString()
                };
                dsS.Add(sach);
            }

            return dsS;
        }

        public static List<Class_Sach> timKiemSach_MaSach(string lok)
        {
            List<Class_Sach> dsS = new List<Class_Sach>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM Sach WHERE MaSach LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_Sach sach = new Class_Sach()
                {
                    MaSach = dr["MaSach"].ToString(),
                    TenSach = dr["TenSach"].ToString(),
                    TacGia = dr["TacGia"].ToString(),
                    TheLoai = dr["TheLoai"].ToString(),
                    NhaXuatBan = dr["NhaXuatBan"].ToString(),
                    GiaSach = int.Parse(dr["GiaSach"].ToString()),
                    TinhTrang = dr["TinhTrang"].ToString()
                };
                dsS.Add(sach);
            }

            return dsS;
        }

        public static List<Class_Sach> timKiemSach_TacGia(string lok)
        {
            List<Class_Sach> dsS = new List<Class_Sach>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM Sach WHERE TacGia LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_Sach sach = new Class_Sach()
                {
                    MaSach = dr["MaSach"].ToString(),
                    TenSach = dr["TenSach"].ToString(),
                    TacGia = dr["TacGia"].ToString(),
                    TheLoai = dr["TheLoai"].ToString(),
                    NhaXuatBan = dr["NhaXuatBan"].ToString(),
                    GiaSach = int.Parse(dr["GiaSach"].ToString()),
                    TinhTrang = dr["TinhTrang"].ToString()
                };
                dsS.Add(sach);
            }

            return dsS;
        }

        public static List<Class_Sach> timKiemSach_NXB(string lok)
        {
            List<Class_Sach> dsS = new List<Class_Sach>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM Sach WHERE NhaXuatBan LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_Sach sach = new Class_Sach()
                {
                    MaSach = dr["MaSach"].ToString(),
                    TenSach = dr["TenSach"].ToString(),
                    TacGia = dr["TacGia"].ToString(),
                    TheLoai = dr["TheLoai"].ToString(),
                    NhaXuatBan = dr["NhaXuatBan"].ToString(),
                    GiaSach = int.Parse(dr["GiaSach"].ToString()),
                    TinhTrang = dr["TinhTrang"].ToString()
                };
                dsS.Add(sach);
            }

            return dsS;
        }

        public static List<Class_Sach> timKiemSach_TheLoai(string lok)
        {
            List<Class_Sach> dsS = new List<Class_Sach>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM Sach WHERE TheLoai LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_Sach sach = new Class_Sach()
                {
                    MaSach = dr["MaSach"].ToString(),
                    TenSach = dr["TenSach"].ToString(),
                    TacGia = dr["TacGia"].ToString(),
                    TheLoai = dr["TheLoai"].ToString(),
                    NhaXuatBan = dr["NhaXuatBan"].ToString(),
                    GiaSach = int.Parse(dr["GiaSach"].ToString()),
                    TinhTrang = dr["TinhTrang"].ToString()
                };
                dsS.Add(sach);
            }

            return dsS;
        }

        public static List<Class_Sach> timKiemSach_TinhTrang(string lok)
        {
            List<Class_Sach> dsS = new List<Class_Sach>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM Sach WHERE TinhTrang LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_Sach sach = new Class_Sach()
                {
                    MaSach = dr["MaSach"].ToString(),
                    TenSach = dr["TenSach"].ToString(),
                    TacGia = dr["TacGia"].ToString(),
                    TheLoai = dr["TheLoai"].ToString(),
                    NhaXuatBan = dr["NhaXuatBan"].ToString(),
                    GiaSach = int.Parse(dr["GiaSach"].ToString()),
                    TinhTrang = dr["TinhTrang"].ToString()
                };
                dsS.Add(sach);
            }

            return dsS;
        }
    }
}
