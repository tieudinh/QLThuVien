﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using QLTV_DTO;

namespace QLTV_DAO
{
    public class TaiKhoan_DAO
    {
        public static List<Class_TaiKhoan> layDSTaiKhoan()
        {
            List<Class_TaiKhoan> dsTK = new List<Class_TaiKhoan>();
            DataTable dt = DataProvider.TruyVan_LayDuLieu("select * from TaiKhoan");
            //DataTable dt = DataProvider.TruyVan_LayDuLieu("SELECT HoTen FROM DocGia WHERE MaDocGia IN (SELECT MaDocGia FROM TaiKhoan)");

            foreach (DataRow dr in dt.Rows)
            {
                Class_TaiKhoan tk = new Class_TaiKhoan();

                tk.MaDocGia = dr["MaDocGia"].ToString();
                tk.TenDangNhap = dr["TenDangNhap"].ToString();
                tk.MatKhau = dr["MatKhau"].ToString();
                tk.VaiTro = int.Parse(dr["VaiTro"].ToString());

                dsTK.Add(tk);
            }

            return dsTK;
        }

        public static Class_TaiKhoan DangNhap(string tendn, string mk)
        {
            if (DataProvider.KiemTraDangNhap(tendn, mk))
            {
                DataRow taiKhoanRow = DataProvider.LayThongTinTaiKhoan(tendn, mk);
                if (taiKhoanRow != null)
                {
                    return new Class_TaiKhoan
                    {
                        TenDangNhap = taiKhoanRow["TenDangNhap"].ToString(),
                        MatKhau = taiKhoanRow["MatKhau"].ToString(),
                        VaiTro = Convert.ToInt32(taiKhoanRow["VaiTro"])
                    };
                }
            }

            return null;
        }

        public static void themTK(Class_TaiKhoan tk)
        {
            string query = "INSERT INTO TaiKhoan(MaDocGia, TenDangNhap, MatKhau, VaiTro) VALUES (@MaDocGia, @TenDangNhap, @MatKhau, @VaiTro)";
            SqlParameter[] sp = new SqlParameter[4];

            sp[0] = new SqlParameter("MaDocGia", tk.MaDocGia);
            sp[1] = new SqlParameter("TenDangNhap", tk.TenDangNhap);
            sp[2] = new SqlParameter("MatKhau", tk.MatKhau);
            sp[3] = new SqlParameter("VaiTro", tk.VaiTro);

            DataProvider.ExcuteNonQuery(query, CommandType.Text, sp);
        }

        public static void suaTK(Class_TaiKhoan tk)
        {
            string query = "update TaiKhoan set MaDocGia = @MaDocGia, TenDangNhap = @TenDangNhap, MatKhau = @MatKhau, VaiTro = @VaiTro";

            SqlParameter[] sp = new SqlParameter[4];

            sp[0] = new SqlParameter("MaDocGia", tk.MaDocGia);
            sp[1] = new SqlParameter("TenDangNhap", tk.TenDangNhap);
            sp[2] = new SqlParameter("MatKhau", tk.MatKhau);
            sp[3] = new SqlParameter("VaiTro", tk.VaiTro);

            DataProvider.ExcuteNonQuery(query, CommandType.Text, sp);
        }

        public static void xoaTK(string madg)
        {
            string query = "delete from TaiKhoan where MaDocGia = @MaDocGia";

            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("@MaDocGia", madg);

            DataProvider.ExcuteNonQuery(query, CommandType.Text, sp);
        }

        public static List<Class_TaiKhoan> timKiemTK_MaDocGia(string lok)
        {
            List<Class_TaiKhoan> dsTK = new List<Class_TaiKhoan>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM TaiKhoan WHERE MaDocGia LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_TaiKhoan tk = new Class_TaiKhoan();

                tk.MaDocGia = dr["MaDocGia"].ToString();
                tk.TenDangNhap = dr["TenDangNhap"].ToString();
                tk.MatKhau = dr["MatKhau"].ToString();
                tk.VaiTro = int.Parse(dr["VaiTro"].ToString());

                dsTK.Add(tk);
            }

            return dsTK;
        }

        public static List<Class_TaiKhoan> timKiemTK_TenDangNhap(string lok)
        {
            List<Class_TaiKhoan> dsTK = new List<Class_TaiKhoan>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM TaiKhoan WHERE TenDangNhap LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_TaiKhoan tk = new Class_TaiKhoan();

                tk.MaDocGia = dr["MaDocGia"].ToString();
                tk.TenDangNhap = dr["TenDangNhap"].ToString();
                tk.MatKhau = dr["MatKhau"].ToString();
                tk.VaiTro = int.Parse(dr["VaiTro"].ToString());

                dsTK.Add(tk);
            }

            return dsTK;
        }
    }
}
