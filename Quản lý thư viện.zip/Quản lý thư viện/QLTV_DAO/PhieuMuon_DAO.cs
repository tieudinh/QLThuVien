﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using QLTV_DTO;

namespace QLTV_DAO
{
    public class PhieuMuon_DAO
    {
        public static List<Class_PhieuMuon> layDSPhieuMuon()
        {
            List<Class_PhieuMuon> dsPM = new List<Class_PhieuMuon>();
            DataTable dt = DataProvider.TruyVan_LayDuLieu("select * from PhieuMuon");

            foreach (DataRow dr in dt.Rows)
            {
                Class_PhieuMuon pm = new Class_PhieuMuon();

                pm.MaPhieu = dr["MaPhieu"].ToString();
                pm.MaDocGia = dr["MaDocGia"].ToString();
                pm.MaSach = dr["MaSach"].ToString();
                pm.NgayMuon = DateTime.Parse(dr["NgayMuon"].ToString());
                pm.NgayPhaiTra = DateTime.Parse(dr["NgayPhaiTra"].ToString());

                dsPM.Add(pm);
            }

            return dsPM;
        }

        public static void themPM(Class_PhieuMuon pm)
        {
            string query = "insert into PhieuMuon(MaPhieu, MaDocGia, MaSach, NgayMuon, NgayPhaiTra) values (@MaPhieu, @MaDocGia, @MaSach, @NgayMuon, @NgayPhaiTra)";
            SqlParameter[] sp = new SqlParameter[5];

            sp[0] = new SqlParameter("MaPhieu", pm.MaPhieu);
            sp[1] = new SqlParameter("MaDocGia", pm.MaDocGia);
            sp[2] = new SqlParameter("MaSach", pm.MaSach); 
            sp[3] = new SqlParameter("NgayMuon", pm.NgayMuon);
            sp[4] = new SqlParameter("NgayPhaiTra", pm.NgayPhaiTra);

            DataProvider.ExcuteNonQuery(query, CommandType.Text, sp);
        }

        public static void xoaPM(string maP)
        {
            string query = "delete from PhieuMuon where MaPhieu = @MaPhieu";

            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("@MaPhieu", maP);

            DataProvider.ExcuteNonQuery(query, CommandType.Text, sp);
        }

        public static void suaPM(Class_PhieuMuon pm)
        {
            string query = "update PhieuMuon set MaDocGia = @MaDocGia, MaSach = @MaSach, NgayMuon = @NgayMuon, NgayPhaiTra = @NgayPhaiTra where MaPhieu = @MaPhieu";
            SqlParameter[] sp = new SqlParameter[5];

            sp[0] = new SqlParameter("MaPhieu", pm.MaPhieu);
            sp[1] = new SqlParameter("MaDocGia", pm.MaDocGia);
            sp[2] = new SqlParameter("MaSach", pm.MaSach);
            sp[3] = new SqlParameter("NgayMuon", pm.NgayMuon);
            sp[4] = new SqlParameter("NgayPhaiTra", pm.NgayPhaiTra);

            DataProvider.ExcuteNonQuery(query, CommandType.Text, sp);
        }

        public static List<Class_PhieuMuon> timKiemPM_DocGia(string lok)
        {
            List<Class_PhieuMuon> dsPM = new List<Class_PhieuMuon>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM PhieuMuon WHERE MaDocGia LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_PhieuMuon pm = new Class_PhieuMuon();

                pm.MaPhieu = dr["MaPhieu"].ToString();
                pm.MaDocGia = dr["MaDocGia"].ToString();
                pm.MaSach = dr["MaSach"].ToString();
                pm.NgayMuon = DateTime.Parse(dr["NgayMuon"].ToString());
                pm.NgayPhaiTra = DateTime.Parse(dr["NgayPhaiTra"].ToString());

                dsPM.Add(pm);
            }

            return dsPM;
        }

        public static List<Class_PhieuMuon> timKiemPM_Sach(string lok)
        {
            List<Class_PhieuMuon> dsPM = new List<Class_PhieuMuon>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM PhieuMuon WHERE MaSach LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_PhieuMuon pm = new Class_PhieuMuon();

                pm.MaPhieu = dr["MaPhieu"].ToString();
                pm.MaDocGia = dr["MaDocGia"].ToString();
                pm.MaSach = dr["MaSach"].ToString();
                pm.NgayMuon = DateTime.Parse(dr["NgayMuon"].ToString());
                pm.NgayPhaiTra = DateTime.Parse(dr["NgayPhaiTra"].ToString());

                dsPM.Add(pm);
            }

            return dsPM;
        }
    }
}
