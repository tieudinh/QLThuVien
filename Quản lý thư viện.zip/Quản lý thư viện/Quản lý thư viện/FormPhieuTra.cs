﻿using QLTV_BUS;
using QLTV_DAO;
using QLTV_DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormPhieuTra : Form
    {
        public FormPhieuTra()
        {
            InitializeComponent();
        }

        private void loadDSPhieuTra()
        {
            dtGVPhieuTra.DataSource = PhieuTra_BUS.layDSPhieuTra();
        }

        private string getNewMaPhieu()
        {
            string query = "select MAX(MaPhieu) from PhieuTra";

            object result = DataProvider.ExecuteScalar(query);

            if (result == DBNull.Value || result == null)
            {
                return "0";
            }
            else
            {
                int maxNumber = int.Parse(result.ToString());
                maxNumber++;
                return maxNumber.ToString();
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                Class_PhieuTra pt = new Class_PhieuTra();

                pt.MaPhieu = getNewMaPhieu();
                pt.MaDocGia = cbReader.SelectedValue.ToString();
                pt.MaSach = cbBook.SelectedValue.ToString();
                pt.NgayTra = dTPNgayTra.Value;

                PhieuTra_BUS.themPT(pt);

                MessageBox.Show("Thêm phiếu thành công!", "Thông báo", MessageBoxButtons.OK);

                loadDSPhieuTra();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (rbtnNguoiMuon.Checked == true)
                dtGVPhieuTra.DataSource = PhieuTra_BUS.timKiemPT_DocGia(txtTimKiem.Text);
            else if (rbtnTenSach.Checked == true)
                dtGVPhieuTra.DataSource = PhieuTra_BUS.timKiemPT_Sach(txtTimKiem.Text);
        }

        private void FormPhieuTra_Load(object sender, EventArgs e)
        {
            cbBook.DataSource = Sach_BUS.layDSSach();
            cbBook.DisplayMember = "TenSach";
            cbBook.ValueMember = "MaSach";
            cbBook.SelectedValue = -1;

            cbReader.DataSource = DocGia_BUS.LayDSDocGia();
            cbReader.DisplayMember = "HoTen";
            cbReader.ValueMember = "MaDocGia";
            cbReader.SelectedValue = -1;

            loadDSPhieuTra();
        }

        private void dtGVPhieuTra_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtMaPhieu.Text = dtGVPhieuTra.Rows[e.RowIndex].Cells[0].Value.ToString();
            dTPNgayTra.Text = dtGVPhieuTra.Rows[e.RowIndex].Cells[3].Value.ToString();

            string maDG = dtGVPhieuTra.Rows[e.RowIndex].Cells[1].Value.ToString();
            foreach (var item in cbReader.Items)
            {
                if (item is Class_DocGia dg && dg.MaDocGia == maDG)
                {
                    cbReader.Text = dg.HoTen;
                    break;
                }
            }

            string maS = dtGVPhieuTra.Rows[e.RowIndex].Cells[2].Value.ToString();
            foreach (var item in cbReader.Items)
            {
                if (item is Class_Sach sach && sach.MaSach == maS)
                {
                    cbBook.Text = sach.MaSach;
                    break;
                }
            }
        }
    }
}
