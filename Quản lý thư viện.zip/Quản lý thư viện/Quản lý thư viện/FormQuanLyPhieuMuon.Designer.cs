﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormQuanLyPhieuMuon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormQuanLyPhieuMuon));
            gbPhieuMuon = new GroupBox();
            txtMaPhieu = new TextBox();
            lblMaPhieu = new Label();
            btnSua = new Button();
            btnXoa = new Button();
            btnThem = new Button();
            rbtnDaTra = new RadioButton();
            rbtnChuaTra = new RadioButton();
            lbTrangThai = new Label();
            dTPNgayTra = new DateTimePicker();
            lbNgayTra = new Label();
            dTPNgayMuon = new DateTimePicker();
            lbNgayMuon = new Label();
            cbBook = new ComboBox();
            lbTenSach = new Label();
            cbReader = new ComboBox();
            lbTenDocGia = new Label();
            dtGVPhieuMuon = new DataGridView();
            panel1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            txtTimKiem = new TextBox();
            btnTimKiem = new Button();
            rbtnTenSach = new RadioButton();
            rbtnNguoiMuon = new RadioButton();
            lbTimKiem = new Label();
            gbPhieuMuon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtGVPhieuMuon).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // gbPhieuMuon
            // 
            gbPhieuMuon.BackColor = SystemColors.ButtonFace;
            gbPhieuMuon.Controls.Add(txtMaPhieu);
            gbPhieuMuon.Controls.Add(lblMaPhieu);
            gbPhieuMuon.Controls.Add(btnSua);
            gbPhieuMuon.Controls.Add(btnXoa);
            gbPhieuMuon.Controls.Add(btnThem);
            gbPhieuMuon.Controls.Add(rbtnDaTra);
            gbPhieuMuon.Controls.Add(rbtnChuaTra);
            gbPhieuMuon.Controls.Add(lbTrangThai);
            gbPhieuMuon.Controls.Add(dTPNgayTra);
            gbPhieuMuon.Controls.Add(lbNgayTra);
            gbPhieuMuon.Controls.Add(dTPNgayMuon);
            gbPhieuMuon.Controls.Add(lbNgayMuon);
            gbPhieuMuon.Controls.Add(cbBook);
            gbPhieuMuon.Controls.Add(lbTenSach);
            gbPhieuMuon.Controls.Add(cbReader);
            gbPhieuMuon.Controls.Add(lbTenDocGia);
            gbPhieuMuon.Location = new Point(3, 3);
            gbPhieuMuon.Name = "gbPhieuMuon";
            gbPhieuMuon.Size = new Size(430, 334);
            gbPhieuMuon.TabIndex = 4;
            gbPhieuMuon.TabStop = false;
            gbPhieuMuon.Enter += gbPhieuMuon_Enter;
            // 
            // txtMaPhieu
            // 
            txtMaPhieu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMaPhieu.Location = new Point(113, 16);
            txtMaPhieu.Name = "txtMaPhieu";
            txtMaPhieu.ReadOnly = true;
            txtMaPhieu.Size = new Size(277, 20);
            txtMaPhieu.TabIndex = 22;
            // 
            // lblMaPhieu
            // 
            lblMaPhieu.AutoSize = true;
            lblMaPhieu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblMaPhieu.Location = new Point(23, 19);
            lblMaPhieu.Name = "lblMaPhieu";
            lblMaPhieu.Size = new Size(58, 13);
            lblMaPhieu.TabIndex = 16;
            lblMaPhieu.Text = "Mã phiếu";
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua.Location = new Point(306, 247);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(84, 32);
            btnSua.TabIndex = 15;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa.Location = new Point(161, 247);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(84, 32);
            btnXoa.TabIndex = 14;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem.Location = new Point(9, 247);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(84, 32);
            btnThem.TabIndex = 13;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // rbtnDaTra
            // 
            rbtnDaTra.AutoSize = true;
            rbtnDaTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnDaTra.Location = new Point(298, 192);
            rbtnDaTra.Name = "rbtnDaTra";
            rbtnDaTra.Size = new Size(61, 17);
            rbtnDaTra.TabIndex = 12;
            rbtnDaTra.TabStop = true;
            rbtnDaTra.Text = "Đã trả";
            rbtnDaTra.UseVisualStyleBackColor = true;
            rbtnDaTra.CheckedChanged += rbtnDaTra_CheckedChanged;
            // 
            // rbtnChuaTra
            // 
            rbtnChuaTra.AutoSize = true;
            rbtnChuaTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnChuaTra.Location = new Point(113, 192);
            rbtnChuaTra.Name = "rbtnChuaTra";
            rbtnChuaTra.Size = new Size(74, 17);
            rbtnChuaTra.TabIndex = 11;
            rbtnChuaTra.TabStop = true;
            rbtnChuaTra.Text = "Chưa trả";
            rbtnChuaTra.UseVisualStyleBackColor = true;
            rbtnChuaTra.CheckedChanged += rbtnChuaTra_CheckedChanged;
            // 
            // lbTrangThai
            // 
            lbTrangThai.AutoSize = true;
            lbTrangThai.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTrangThai.Location = new Point(23, 191);
            lbTrangThai.Name = "lbTrangThai";
            lbTrangThai.Size = new Size(65, 13);
            lbTrangThai.TabIndex = 10;
            lbTrangThai.Text = "Tình trạng";
            lbTrangThai.Click += lbTrangThai_Click;
            // 
            // dTPNgayTra
            // 
            dTPNgayTra.CalendarFont = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayTra.Location = new Point(113, 146);
            dTPNgayTra.Name = "dTPNgayTra";
            dTPNgayTra.Size = new Size(277, 20);
            dTPNgayTra.TabIndex = 9;
            dTPNgayTra.ValueChanged += dTPNgayTra_ValueChanged;
            // 
            // lbNgayTra
            // 
            lbNgayTra.AutoSize = true;
            lbNgayTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNgayTra.Location = new Point(23, 153);
            lbNgayTra.Name = "lbNgayTra";
            lbNgayTra.Size = new Size(55, 13);
            lbNgayTra.TabIndex = 8;
            lbNgayTra.Text = "Ngày trả";
            lbNgayTra.Click += lbNgayTra_Click;
            // 
            // dTPNgayMuon
            // 
            dTPNgayMuon.CalendarFont = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayMuon.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayMuon.Location = new Point(113, 114);
            dTPNgayMuon.Name = "dTPNgayMuon";
            dTPNgayMuon.Size = new Size(277, 20);
            dTPNgayMuon.TabIndex = 7;
            dTPNgayMuon.ValueChanged += dTPNgayMuon_ValueChanged;
            // 
            // lbNgayMuon
            // 
            lbNgayMuon.AutoSize = true;
            lbNgayMuon.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNgayMuon.Location = new Point(23, 121);
            lbNgayMuon.Name = "lbNgayMuon";
            lbNgayMuon.Size = new Size(71, 13);
            lbNgayMuon.TabIndex = 6;
            lbNgayMuon.Text = "Ngày mượn";
            lbNgayMuon.Click += lbNgayMuon_Click;
            // 
            // cbBook
            // 
            cbBook.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            cbBook.FormattingEnabled = true;
            cbBook.Location = new Point(113, 81);
            cbBook.Name = "cbBook";
            cbBook.Size = new Size(277, 20);
            cbBook.TabIndex = 5;
            cbBook.SelectedIndexChanged += cbBook_SelectedIndexChanged;
            // 
            // lbTenSach
            // 
            lbTenSach.AutoSize = true;
            lbTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenSach.Location = new Point(20, 85);
            lbTenSach.Name = "lbTenSach";
            lbTenSach.Size = new Size(57, 13);
            lbTenSach.TabIndex = 4;
            lbTenSach.Text = "Tên sách";
            lbTenSach.Click += lbTenSach_Click;
            // 
            // cbReader
            // 
            cbReader.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            cbReader.FormattingEnabled = true;
            cbReader.Location = new Point(113, 49);
            cbReader.Name = "cbReader";
            cbReader.Size = new Size(277, 20);
            cbReader.TabIndex = 3;
            cbReader.SelectedIndexChanged += cbReader_SelectedIndexChanged;
            // 
            // lbTenDocGia
            // 
            lbTenDocGia.AutoSize = true;
            lbTenDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenDocGia.Location = new Point(20, 52);
            lbTenDocGia.Name = "lbTenDocGia";
            lbTenDocGia.Size = new Size(75, 13);
            lbTenDocGia.TabIndex = 2;
            lbTenDocGia.Text = "Người mượn";
            lbTenDocGia.Click += lbTenDocGia_Click;
            // 
            // dtGVPhieuMuon
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.DarkSlateGray;
            dataGridViewCellStyle1.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dataGridViewCellStyle1.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle1.SelectionBackColor = Color.Teal;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dtGVPhieuMuon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dtGVPhieuMuon.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.Font = new Font("Tahoma", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = Color.DarkCyan;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dtGVPhieuMuon.DefaultCellStyle = dataGridViewCellStyle2;
            dtGVPhieuMuon.Location = new Point(0, 0);
            dtGVPhieuMuon.Name = "dtGVPhieuMuon";
            dtGVPhieuMuon.RowHeadersWidth = 51;
            dtGVPhieuMuon.RowTemplate.Height = 24;
            dtGVPhieuMuon.Size = new Size(734, 206);
            dtGVPhieuMuon.TabIndex = 5;
            dtGVPhieuMuon.RowHeaderMouseClick += dtGVPhieuMuon_RowHeaderMouseClick;
            // 
            // panel1
            // 
            panel1.Controls.Add(gbPhieuMuon);
            panel1.Location = new Point(10, 11);
            panel1.Name = "panel1";
            panel1.Size = new Size(438, 339);
            panel1.TabIndex = 6;
            // 
            // panel2
            // 
            panel2.Controls.Add(dtGVPhieuMuon);
            panel2.Location = new Point(10, 353);
            panel2.Name = "panel2";
            panel2.Size = new Size(737, 206);
            panel2.TabIndex = 7;
            // 
            // panel3
            // 
            panel3.Controls.Add(txtTimKiem);
            panel3.Controls.Add(btnTimKiem);
            panel3.Controls.Add(rbtnTenSach);
            panel3.Controls.Add(rbtnNguoiMuon);
            panel3.Controls.Add(lbTimKiem);
            panel3.Location = new Point(453, 11);
            panel3.Name = "panel3";
            panel3.Size = new Size(294, 339);
            panel3.TabIndex = 8;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTimKiem.Location = new Point(41, 52);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(213, 20);
            txtTimKiem.TabIndex = 20;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnTimKiem.Location = new Point(41, 249);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(213, 27);
            btnTimKiem.TabIndex = 21;
            btnTimKiem.Text = "Tìm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // rbtnTenSach
            // 
            rbtnTenSach.AutoSize = true;
            rbtnTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnTenSach.Location = new Point(56, 118);
            rbtnTenSach.Name = "rbtnTenSach";
            rbtnTenSach.Size = new Size(75, 17);
            rbtnTenSach.TabIndex = 19;
            rbtnTenSach.TabStop = true;
            rbtnTenSach.Text = "Tên sách";
            rbtnTenSach.UseVisualStyleBackColor = true;
            // 
            // rbtnNguoiMuon
            // 
            rbtnNguoiMuon.AutoSize = true;
            rbtnNguoiMuon.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnNguoiMuon.Location = new Point(56, 94);
            rbtnNguoiMuon.Name = "rbtnNguoiMuon";
            rbtnNguoiMuon.Size = new Size(117, 17);
            rbtnNguoiMuon.TabIndex = 18;
            rbtnNguoiMuon.TabStop = true;
            rbtnNguoiMuon.Text = "Tên người mượn";
            rbtnNguoiMuon.UseVisualStyleBackColor = true;
            // 
            // lbTimKiem
            // 
            lbTimKiem.AutoSize = true;
            lbTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTimKiem.Location = new Point(3, 22);
            lbTimKiem.Name = "lbTimKiem";
            lbTimKiem.Size = new Size(88, 13);
            lbTimKiem.TabIndex = 17;
            lbTimKiem.Text = "Tìm kiếm theo";
            // 
            // FormQuanLyPhieuMuon
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(878, 571);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "FormQuanLyPhieuMuon";
            Text = "FormQuanLyPhieuMuon";
            Load += FormQuanLyPhieuMuon_Load;
            gbPhieuMuon.ResumeLayout(false);
            gbPhieuMuon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtGVPhieuMuon).EndInit();
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox gbPhieuMuon;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.RadioButton rbtnDaTra;
        private System.Windows.Forms.RadioButton rbtnChuaTra;
        private System.Windows.Forms.Label lbTrangThai;
        private System.Windows.Forms.DateTimePicker dTPNgayTra;
        private System.Windows.Forms.Label lbNgayTra;
        private System.Windows.Forms.DateTimePicker dTPNgayMuon;
        private System.Windows.Forms.Label lbNgayMuon;
        private System.Windows.Forms.ComboBox cbBook;
        private System.Windows.Forms.Label lbTenSach;
        private System.Windows.Forms.ComboBox cbReader;
        private System.Windows.Forms.Label lbTenDocGia;
        private System.Windows.Forms.DataGridView dtGVPhieuMuon;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbTimKiem;
        private System.Windows.Forms.RadioButton rbtnTenSach;
        private System.Windows.Forms.RadioButton rbtnNguoiMuon;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Button btnTimKiem;
        private TextBox txtMaPhieu;
        private Label lblMaPhieu;
    }
}