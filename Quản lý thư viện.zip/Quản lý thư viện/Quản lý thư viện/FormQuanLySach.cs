﻿using QLTV_BUS;
using QLTV_DAO;
using QLTV_DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormQuanLySach : Form
    {
        public FormQuanLySach()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dtGVSach_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void loadDS()
        {
            dtGVSach.DataSource = Sach_BUS.layDSSach();
        }

        private string getNewMaSach()
        {
            string query = "select MAX(MaSach) from Sach";
            object result = DataProvider.ExecuteScalar(query);

            if (result == DBNull.Value || result == null)
            {
                return "0";
            }
            else
            {
                int maxNumber = int.Parse(result.ToString());
                maxNumber++;
                return maxNumber.ToString();
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Kiểm tra lỗi nhập liệu (nếu có)
            if (string.IsNullOrEmpty(txtTenSach.Text) || string.IsNullOrEmpty(txtTheLoai.Text) ||
                string.IsNullOrEmpty(txtTacGia.Text) || string.IsNullOrEmpty(txtNXB.Text) ||
                !int.TryParse(txtGiaSach.Text, out int giaSach))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin sách và đảm bảo giá sách hợp lệ.");
            }
            else
            {
                try
                {
                    Class_Sach sach = new Class_Sach()
                    {
                        MaSach = getNewMaSach(),
                        TenSach = txtTenSach.Text,
                        TheLoai = txtTheLoai.Text,
                        TacGia = txtTacGia.Text,
                        NhaXuatBan = txtNXB.Text,
                        GiaSach = giaSach,
                        TinhTrang = txtTinhTrang.Text
                    };

                    Sach_BUS.themSach(sach);
                    loadDS();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dtGVSach.SelectedRows.Count == 0)
            {
                MessageBox.Show("Hãy chọn sách muốn xoá");
            }
            else
            {
                var selectedRow = dtGVSach.SelectedRows[0];
                string maSach = selectedRow.Cells["Mã sách"].Value.ToString();


                var result = MessageBox.Show("Bạn chắc chắn muốn xóa sách này?", "Xóa sách", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Sach_BUS.xoaSach(maSach);
                    loadDS();
                }
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dtGVSach.SelectedRows.Count == 0)
            {
                MessageBox.Show("Hãy chọn sách muốn sửa");
            }
            else
            {
                var selectedRow = dtGVSach.SelectedRows[0];
                Class_Sach sach = new Class_Sach()
                {
                    MaSach = txtMaSach.Text,
                    TenSach = txtTenSach.Text,
                    TacGia = txtTacGia.Text,
                    TheLoai = txtTheLoai.Text,
                    NhaXuatBan = txtNXB.Text,
                    TinhTrang = txtTinhTrang.Text,
                    GiaSach = int.Parse(txtGiaSach.Text),
                };

                Sach_BUS.suaSach(sach);
                loadDS();

            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (rbtnMaSach.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimMaSach(txtTimKiem.Text.Trim());
            else if (rbtnTenSach.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTen(txtTimKiem.Text.Trim());
            else if (rbtnTacGia.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTacGia(txtTimKiem.Text.Trim());
            else if (rbtnTheLoai.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTheLoai(txtTimKiem.Text.Trim());
            else if (rbtnTinhTrang.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTinhTrang(txtTimKiem.Text.Trim());
        }

        private void dtGVSach_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtMaSach.Text = dtGVSach.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTenSach.Text = dtGVSach.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtTacGia.Text = dtGVSach.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtTheLoai.Text = dtGVSach.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtNXB.Text = dtGVSach.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtGiaSach.Text = dtGVSach.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtTinhTrang.Text = dtGVSach.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        private void FormQuanLySach_Load(object sender, EventArgs e)
        {
            loadDS();
        }
    }
}
