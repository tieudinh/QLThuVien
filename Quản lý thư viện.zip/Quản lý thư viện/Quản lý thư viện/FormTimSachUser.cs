﻿using QLTV_BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormTimSachUser : Form
    {
        public FormTimSachUser()
        {
            InitializeComponent();
        }

        private void dtGVSach_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtMaSach.Text = dtGVSach.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTenSach.Text = dtGVSach.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtTacGia.Text = dtGVSach.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtTheLoai.Text = dtGVSach.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtNXB.Text = dtGVSach.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtGiaSach.Text = dtGVSach.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtTinhTrang.Text = dtGVSach.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        private void FormTimSachUser_Load(object sender, EventArgs e)
        {
            dtGVSach.DataSource = Sach_BUS.layDSSach();
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (rbtnMaSach.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimMaSach(txtTimKiem.Text.Trim());
            else if (rbtnTenSach.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTen(txtTimKiem.Text.Trim());
            else if (rbtnTacGia.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTacGia(txtTimKiem.Text.Trim());
            else if (rbtnTheLoai.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTheLoai(txtTimKiem.Text.Trim());
            else if (rbtnTinhTrang.Checked == true)
                dtGVSach.DataSource = Sach_BUS.TimTinhTrang(txtTimKiem.Text.Trim());
        }
    }
}
