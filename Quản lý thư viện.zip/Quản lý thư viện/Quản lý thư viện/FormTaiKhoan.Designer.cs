﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormTaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTaiKhoan));
            panel_DS = new Panel();
            dtGVTK = new DataGridView();
            panel_TK = new Panel();
            lblLuuY = new Label();
            btnSua = new Button();
            btnXoa = new Button();
            btnThem = new Button();
            txtVaiTro = new TextBox();
            lbVaiTro = new Label();
            txtMatKhau = new TextBox();
            lbMatKhau = new Label();
            txtTenDangNhap = new TextBox();
            lbTenDangNhap = new Label();
            txtMaDocGia = new TextBox();
            lbMaDocGia = new Label();
            panel_TimKiem = new Panel();
            rbtnTenDangNhap = new RadioButton();
            rbtnMaDocGia = new RadioButton();
            btnTimKiemTK = new Button();
            txtTimKiem = new TextBox();
            btnTimKiem = new Button();
            lbTimKiem = new Label();
            panel_DS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtGVTK).BeginInit();
            panel_TK.SuspendLayout();
            panel_TimKiem.SuspendLayout();
            SuspendLayout();
            // 
            // panel_DS
            // 
            panel_DS.Controls.Add(dtGVTK);
            panel_DS.Location = new Point(10, 236);
            panel_DS.Name = "panel_DS";
            panel_DS.Size = new Size(639, 340);
            panel_DS.TabIndex = 0;
            // 
            // dtGVTK
            // 
            dtGVTK.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtGVTK.Location = new Point(0, 0);
            dtGVTK.Name = "dtGVTK";
            dtGVTK.RowHeadersWidth = 51;
            dtGVTK.RowTemplate.Height = 24;
            dtGVTK.Size = new Size(639, 340);
            dtGVTK.TabIndex = 0;
            dtGVTK.RowHeaderMouseClick += dtGVTK_RowHeaderMouseClick;
            // 
            // panel_TK
            // 
            panel_TK.Controls.Add(lblLuuY);
            panel_TK.Controls.Add(btnSua);
            panel_TK.Controls.Add(btnXoa);
            panel_TK.Controls.Add(btnThem);
            panel_TK.Controls.Add(txtVaiTro);
            panel_TK.Controls.Add(lbVaiTro);
            panel_TK.Controls.Add(txtMatKhau);
            panel_TK.Controls.Add(lbMatKhau);
            panel_TK.Controls.Add(txtTenDangNhap);
            panel_TK.Controls.Add(lbTenDangNhap);
            panel_TK.Controls.Add(txtMaDocGia);
            panel_TK.Controls.Add(lbMaDocGia);
            panel_TK.Location = new Point(10, 11);
            panel_TK.Name = "panel_TK";
            panel_TK.Size = new Size(325, 219);
            panel_TK.TabIndex = 1;
            // 
            // lblLuuY
            // 
            lblLuuY.AutoSize = true;
            lblLuuY.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblLuuY.Location = new Point(3, 127);
            lblLuuY.Name = "lblLuuY";
            lblLuuY.Size = new Size(306, 26);
            lblLuuY.TabIndex = 19;
            lblLuuY.Text = "*Lưu ý: Nếu bạn muốn thêm hoặc xoá một tài khoản, \r\nbạn phải thao tác từ trang Độc Giả để tránh lỗi";
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua.Location = new Point(219, 178);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(87, 27);
            btnSua.TabIndex = 18;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa.Location = new Point(127, 178);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(87, 27);
            btnXoa.TabIndex = 17;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Visible = false;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem.Location = new Point(35, 178);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(87, 27);
            btnThem.TabIndex = 16;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Visible = false;
            // 
            // txtVaiTro
            // 
            txtVaiTro.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtVaiTro.Location = new Point(112, 96);
            txtVaiTro.Name = "txtVaiTro";
            txtVaiTro.Size = new Size(194, 20);
            txtVaiTro.TabIndex = 9;
            // 
            // lbVaiTro
            // 
            lbVaiTro.AutoSize = true;
            lbVaiTro.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbVaiTro.Location = new Point(3, 98);
            lbVaiTro.Name = "lbVaiTro";
            lbVaiTro.Size = new Size(46, 13);
            lbVaiTro.TabIndex = 8;
            lbVaiTro.Text = "Vai Trò";
            // 
            // txtMatKhau
            // 
            txtMatKhau.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMatKhau.Location = new Point(112, 68);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.Size = new Size(194, 20);
            txtMatKhau.TabIndex = 7;
            // 
            // lbMatKhau
            // 
            lbMatKhau.AutoSize = true;
            lbMatKhau.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbMatKhau.Location = new Point(3, 71);
            lbMatKhau.Name = "lbMatKhau";
            lbMatKhau.Size = new Size(60, 13);
            lbMatKhau.TabIndex = 6;
            lbMatKhau.Text = "Mật khẩu";
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTenDangNhap.Location = new Point(112, 41);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.ReadOnly = true;
            txtTenDangNhap.Size = new Size(194, 20);
            txtTenDangNhap.TabIndex = 5;
            // 
            // lbTenDangNhap
            // 
            lbTenDangNhap.AutoSize = true;
            lbTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenDangNhap.Location = new Point(3, 44);
            lbTenDangNhap.Name = "lbTenDangNhap";
            lbTenDangNhap.Size = new Size(90, 13);
            lbTenDangNhap.TabIndex = 4;
            lbTenDangNhap.Text = "Tên đăng nhập";
            // 
            // txtMaDocGia
            // 
            txtMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMaDocGia.Location = new Point(112, 14);
            txtMaDocGia.Name = "txtMaDocGia";
            txtMaDocGia.ReadOnly = true;
            txtMaDocGia.Size = new Size(194, 20);
            txtMaDocGia.TabIndex = 3;
            // 
            // lbMaDocGia
            // 
            lbMaDocGia.AutoSize = true;
            lbMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbMaDocGia.Location = new Point(3, 17);
            lbMaDocGia.Name = "lbMaDocGia";
            lbMaDocGia.Size = new Size(67, 13);
            lbMaDocGia.TabIndex = 2;
            lbMaDocGia.Text = "Mã độc giả";
            // 
            // panel_TimKiem
            // 
            panel_TimKiem.Controls.Add(rbtnTenDangNhap);
            panel_TimKiem.Controls.Add(rbtnMaDocGia);
            panel_TimKiem.Controls.Add(btnTimKiemTK);
            panel_TimKiem.Controls.Add(txtTimKiem);
            panel_TimKiem.Controls.Add(btnTimKiem);
            panel_TimKiem.Controls.Add(lbTimKiem);
            panel_TimKiem.Location = new Point(340, 11);
            panel_TimKiem.Name = "panel_TimKiem";
            panel_TimKiem.Size = new Size(309, 219);
            panel_TimKiem.TabIndex = 3;
            // 
            // rbtnTenDangNhap
            // 
            rbtnTenDangNhap.AutoSize = true;
            rbtnTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold);
            rbtnTenDangNhap.Location = new Point(52, 135);
            rbtnTenDangNhap.Name = "rbtnTenDangNhap";
            rbtnTenDangNhap.Size = new Size(108, 17);
            rbtnTenDangNhap.TabIndex = 20;
            rbtnTenDangNhap.TabStop = true;
            rbtnTenDangNhap.Text = "Tên đăng nhập";
            rbtnTenDangNhap.UseVisualStyleBackColor = true;
            // 
            // rbtnMaDocGia
            // 
            rbtnMaDocGia.AutoSize = true;
            rbtnMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold);
            rbtnMaDocGia.Location = new Point(52, 94);
            rbtnMaDocGia.Name = "rbtnMaDocGia";
            rbtnMaDocGia.Size = new Size(85, 17);
            rbtnMaDocGia.TabIndex = 19;
            rbtnMaDocGia.TabStop = true;
            rbtnMaDocGia.Text = "Mã độc giả";
            rbtnMaDocGia.UseVisualStyleBackColor = true;
            // 
            // btnTimKiemTK
            // 
            btnTimKiemTK.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnTimKiemTK.Location = new Point(52, 178);
            btnTimKiemTK.Name = "btnTimKiemTK";
            btnTimKiemTK.Size = new Size(213, 27);
            btnTimKiemTK.TabIndex = 17;
            btnTimKiemTK.Text = "Tìm";
            btnTimKiemTK.UseVisualStyleBackColor = true;
            btnTimKiemTK.Click += btnTimKiemTK_Click;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTimKiem.Location = new Point(52, 41);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(213, 20);
            txtTimKiem.TabIndex = 16;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnTimKiem.Location = new Point(32, 218);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(213, 27);
            btnTimKiem.TabIndex = 16;
            btnTimKiem.Text = "Tìm";
            btnTimKiem.UseVisualStyleBackColor = true;
            // 
            // lbTimKiem
            // 
            lbTimKiem.AutoSize = true;
            lbTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTimKiem.Location = new Point(3, 10);
            lbTimKiem.Name = "lbTimKiem";
            lbTimKiem.Size = new Size(144, 13);
            lbTimKiem.TabIndex = 16;
            lbTimKiem.Text = "Tìm kiếm tài khoản theo";
            // 
            // FormTaiKhoan
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(712, 588);
            Controls.Add(panel_TimKiem);
            Controls.Add(panel_TK);
            Controls.Add(panel_DS);
            Name = "FormTaiKhoan";
            Text = "FormTaiKhoan";
            Load += FormTaiKhoan_Load;
            panel_DS.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtGVTK).EndInit();
            panel_TK.ResumeLayout(false);
            panel_TK.PerformLayout();
            panel_TimKiem.ResumeLayout(false);
            panel_TimKiem.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel_DS;
        private System.Windows.Forms.Panel panel_TK;
        private System.Windows.Forms.TextBox txtMaDocGia;
        private System.Windows.Forms.Label lbMaDocGia;
        private System.Windows.Forms.TextBox txtVaiTro;
        private System.Windows.Forms.Label lbVaiTro;
        private System.Windows.Forms.TextBox txtMatKhau;
        private System.Windows.Forms.Label lbMatKhau;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.Label lbTenDangNhap;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DataGridView dtGVTK;
        private System.Windows.Forms.Panel panel_TimKiem;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Label lbTimKiem;
        private System.Windows.Forms.Button btnTimKiemTK;
        private Label lblLuuY;
        private RadioButton rbtnTenDangNhap;
        private RadioButton rbtnMaDocGia;
    }
}