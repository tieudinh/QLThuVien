﻿using QLTV_BUS;
using QLTV_DAO;
using QLTV_DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormDocGia : Form
    {
        public FormDocGia()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void displayList()
        {
            dgvDocGia.DataSource = DocGia_BUS.LayDSDocGia();
        }

        private void FormDocGia_Load(object sender, EventArgs e)
        {
            displayList();
        }

        private void clearFields()
        {
            txtMaDocGia.Clear();
            txtTenDangNhap.Clear();
            txtHoTen.Clear();
            txtNamSinh.Clear();
            txtDiaChi.Clear();
            txtSDT.Clear();
            rbtnNam.Checked = false;
            rbtnNu.Checked = false;
        }

        private string getNewMaDocGia()
        {
            string query = "SELECT MAX(CAST(SUBSTRING(MaDocGia, 5, LEN(MaDocGia) - 4) AS INT)) FROM DocGia WHERE MaDocGia LIKE 'user%'";

            object result = DataProvider.ExecuteScalar(query);

            if (result == DBNull.Value || result == null)
            {
                return "user0";
            }
            else
            {
                int maxNumber = int.Parse(result.ToString());
                maxNumber++;
                return "user" + maxNumber;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                //Thêm vào bảng DocGia
                Class_DocGia dg = new Class_DocGia();

                dg.MaDocGia = getNewMaDocGia();
                dg.TenDangNhap = txtTenDangNhap.Text.Trim();
                dg.HoTen = txtHoTen.Text.Trim();
                dg.DiaChi = txtDiaChi.Text.Trim();

                if (rbtnNam.Checked == true)
                {
                    dg.GioiTinh = "Nam";
                }
                else if (rbtnNu.Checked == true)
                {
                    dg.GioiTinh = "Nữ";
                }

                dg.NamSinh = int.Parse(txtNamSinh.Text.Trim());
                dg.SDT = txtSDT.Text.Trim();

                DocGia_BUS.themDG(dg);

                //Thêm vào bảng TaiKhoan

                Class_TaiKhoan tk = new Class_TaiKhoan();

                tk.MaDocGia = dg.MaDocGia;
                tk.TenDangNhap = dg.TenDangNhap;
                tk.MatKhau = dg.TenDangNhap + dg.NamSinh;
                tk.VaiTro = 0;

                TaiKhoan_BUS.themTK(tk);

                MessageBox.Show("Thêm độc giả thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                displayList();

                clearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvDocGia_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtMaDocGia.Text = dgvDocGia.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTenDangNhap.Text = dgvDocGia.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtHoTen.Text = dgvDocGia.Rows[e.RowIndex].Cells[2].Value.ToString();

            //txtMaDocGia.Text = dgvQLDocGia.Rows[e.RowIndex].Cells[3].Value.ToString();
            if (dgvDocGia.Rows[e.RowIndex].Cells[3].Value.ToString() == "Nam")
            {
                rbtnNam.Checked = true;
            }
            else if (dgvDocGia.Rows[e.RowIndex].Cells[3].Value.ToString() == "Nu" || dgvDocGia.Rows[e.RowIndex].Cells[3].Value.ToString() == "Nữ")
            {
                rbtnNu.Checked = true;
            }

            txtNamSinh.Text = dgvDocGia.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtDiaChi.Text = dgvDocGia.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtSDT.Text = dgvDocGia.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //Xoá trong bảng DocGia
            if (dgvDocGia.SelectedRows.Count > 0)
            {
                string madg = dgvDocGia.SelectedRows[0].Cells[0].Value.ToString();

                DialogResult result = MessageBox.Show(
                    "Bạn có chắc chắn muốn xóa độc giả có mã [" + madg + "] ?",
                    "Xác nhận xóa",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        DocGia_BUS.xoaDG(madg);

                        MessageBox.Show("Xóa độc giả thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        displayList();

                        clearFields();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Đã xảy ra lỗi khi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn độc giả để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            //Xửa thông tin trong DocGia
            try
            {
                Class_DocGia dg = new Class_DocGia();

                dg.MaDocGia = txtMaDocGia.Text;
                dg.TenDangNhap = txtTenDangNhap.Text.Trim();
                dg.HoTen = txtHoTen.Text.Trim();
                dg.DiaChi = txtDiaChi.Text.Trim();

                //dg.GioiTinh = txtGioiTinh.Text.Trim();
                if (rbtnNam.Checked == true)
                {
                    dg.GioiTinh = "Nam";
                }
                else if (rbtnNu.Checked == true)
                {
                    dg.GioiTinh = "Nữ";
                }

                dg.NamSinh = int.Parse(txtNamSinh.Text.Trim());
                dg.SDT = txtSDT.Text.Trim();

                DocGia_BUS.suaDG(dg);

                //Sửa thông tin trong TaiKhoan
                Class_TaiKhoan tk = new Class_TaiKhoan();

                tk.MaDocGia = dg.MaDocGia;
                tk.TenDangNhap = dg.TenDangNhap;
                tk.MatKhau = tk.MatKhau;
                tk.VaiTro = tk.VaiTro;

                TaiKhoan_BUS.suaTK(tk);

                MessageBox.Show("Sửa thông tin độc giả thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                displayList();

                clearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (rbtnHoTen.Checked == true)
                dgvDocGia.DataSource = DocGia_BUS.timKiemDG_HoTen(txtTimKiem.Text.Trim());
            else if (rbtnMaDocGia.Checked == true)
                dgvDocGia.DataSource = DocGia_BUS.timKiemDG_MaDocGia(txtTimKiem.Text.Trim());
            else if (rbtnTenDangNhap.Checked == true)
                dgvDocGia.DataSource = DocGia_BUS.timKiemDG_TenDangNhap(txtTimKiem.Text.Trim());

            dgvDocGia.AutoResizeColumns();
        }
    }
}
