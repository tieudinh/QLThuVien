﻿using QLTV_DTO;
using QLTV_DAO;
using QLTV_BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormTaiKhoanUser : Form
    {
        public FormTaiKhoanUser()
        {
            InitializeComponent();
        }

        private void loadTTDocGia()
        {
            dgvThongTinDG.DataSource = DocGia_BUS.LayDSDocGia();
        }

        private void FormTaiKhoanUser_Load(object sender, EventArgs e)
        {
            loadTTDocGia();
        }

        private void dgvThongTinDG_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtMaDocGia.Text = dgvThongTinDG.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTenDangNhap.Text = dgvThongTinDG.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtHoTen.Text = dgvThongTinDG.Rows[e.RowIndex].Cells[2].Value.ToString();

            //txtMaDocGia.Text = dgvQLDocGia.Rows[e.RowIndex].Cells[3].Value.ToString();
            if (dgvThongTinDG.Rows[e.RowIndex].Cells[3].Value.ToString() == "Nam")
            {
                rbtnNam.Checked = true;
            }
            else if (dgvThongTinDG.Rows[e.RowIndex].Cells[3].Value.ToString() == "Nu" || dgvThongTinDG.Rows[e.RowIndex].Cells[3].Value.ToString() == "Nữ")
            {
                rbtnNu.Checked = true;
            }

            txtNamSinh.Text = dgvThongTinDG.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtDiaChi.Text = dgvThongTinDG.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtSDT.Text = dgvThongTinDG.Rows[e.RowIndex].Cells[6].Value.ToString();
        }
    }
}
