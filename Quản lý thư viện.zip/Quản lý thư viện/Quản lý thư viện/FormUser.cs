﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormUser : Form
    {
        public FormUser()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;

        }

        private Form currentFormChild;

        private void OpenFormChild(Form childform)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();
            }

            currentFormChild = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panel_body.Controls.Add(childform);
            panel_body.Tag = childform;
            childform.BringToFront();
            childform.Show();

        }

        private void FormUser_Load(object sender, EventArgs e)
        {

        }

        private void btnSach_Click(object sender, EventArgs e)
        {
            OpenFormChild(new FormTimSachUser());
        }

        private void btnTaiKhoan_Click(object sender, EventArgs e)
        {
            OpenFormChild(new FormTaiKhoanUser());
        }

        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có muốn thoát khỏi chương trình hay không", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            {
                if (dr == DialogResult.Yes)
                {
                    this.Close();

                }
            }
        }

        private void btnTheMuon_Click(object sender, EventArgs e)
        {
            OpenFormChild(new FormPhieuMuonUser());
        }
    }
}
