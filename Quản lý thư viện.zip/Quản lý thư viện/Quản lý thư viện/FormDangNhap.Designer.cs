﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormDangNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDangNhap));
            pBBackground = new PictureBox();
            lbTenDangNhap = new Label();
            txtTenDangNhap = new TextBox();
            lbGioiThieu = new Label();
            lbPassword = new Label();
            txtPass = new TextBox();
            btnDangNhap = new Button();
            btnThoat = new Button();
            gbDangNhap = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)pBBackground).BeginInit();
            gbDangNhap.SuspendLayout();
            SuspendLayout();
            // 
            // pBBackground
            // 
            pBBackground.Dock = DockStyle.Fill;
            pBBackground.Image = (Image)resources.GetObject("pBBackground.Image");
            pBBackground.Location = new Point(0, 0);
            pBBackground.Margin = new Padding(2);
            pBBackground.Name = "pBBackground";
            pBBackground.Size = new Size(700, 422);
            pBBackground.SizeMode = PictureBoxSizeMode.StretchImage;
            pBBackground.TabIndex = 0;
            pBBackground.TabStop = false;
            // 
            // lbTenDangNhap
            // 
            lbTenDangNhap.AutoSize = true;
            lbTenDangNhap.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenDangNhap.Location = new Point(38, 90);
            lbTenDangNhap.Margin = new Padding(2, 0, 2, 0);
            lbTenDangNhap.Name = "lbTenDangNhap";
            lbTenDangNhap.Size = new Size(112, 17);
            lbTenDangNhap.TabIndex = 0;
            lbTenDangNhap.Text = "Tên đăng nhập";
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTenDangNhap.Location = new Point(177, 88);
            txtTenDangNhap.Margin = new Padding(2);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.Size = new Size(241, 24);
            txtTenDangNhap.TabIndex = 1;
            // 
            // lbGioiThieu
            // 
            lbGioiThieu.AutoSize = true;
            lbGioiThieu.Font = new Font("Tahoma", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbGioiThieu.Location = new Point(63, 17);
            lbGioiThieu.Margin = new Padding(2, 0, 2, 0);
            lbGioiThieu.Name = "lbGioiThieu";
            lbGioiThieu.Size = new Size(309, 36);
            lbGioiThieu.TabIndex = 2;
            lbGioiThieu.Text = "QUẢN LÝ THƯ VIỆN";
            lbGioiThieu.TextAlign = ContentAlignment.TopCenter;
            // 
            // lbPassword
            // 
            lbPassword.AutoSize = true;
            lbPassword.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbPassword.Location = new Point(38, 143);
            lbPassword.Margin = new Padding(2, 0, 2, 0);
            lbPassword.Name = "lbPassword";
            lbPassword.Size = new Size(72, 17);
            lbPassword.TabIndex = 3;
            lbPassword.Text = "Mật khẩu";
            lbPassword.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // txtPass
            // 
            txtPass.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtPass.Location = new Point(177, 140);
            txtPass.Margin = new Padding(2);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(241, 24);
            txtPass.TabIndex = 4;
            // 
            // btnDangNhap
            // 
            btnDangNhap.BackColor = Color.CadetBlue;
            btnDangNhap.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnDangNhap.Location = new Point(34, 193);
            btnDangNhap.Margin = new Padding(2);
            btnDangNhap.Name = "btnDangNhap";
            btnDangNhap.Size = new Size(113, 37);
            btnDangNhap.TabIndex = 5;
            btnDangNhap.Text = "Đăng nhập";
            btnDangNhap.UseVisualStyleBackColor = false;
            btnDangNhap.Click += btnDangNhap_Click;
            // 
            // btnThoat
            // 
            btnThoat.BackColor = Color.LightCoral;
            btnThoat.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat.Location = new Point(304, 193);
            btnThoat.Margin = new Padding(2);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(113, 37);
            btnThoat.TabIndex = 6;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = false;
            btnThoat.Click += btnThoat_Click;
            // 
            // gbDangNhap
            // 
            gbDangNhap.Controls.Add(btnThoat);
            gbDangNhap.Controls.Add(btnDangNhap);
            gbDangNhap.Controls.Add(txtPass);
            gbDangNhap.Controls.Add(lbPassword);
            gbDangNhap.Controls.Add(lbGioiThieu);
            gbDangNhap.Controls.Add(txtTenDangNhap);
            gbDangNhap.Controls.Add(lbTenDangNhap);
            gbDangNhap.Location = new Point(118, 67);
            gbDangNhap.Margin = new Padding(2);
            gbDangNhap.Name = "gbDangNhap";
            gbDangNhap.Padding = new Padding(2);
            gbDangNhap.Size = new Size(456, 279);
            gbDangNhap.TabIndex = 1;
            gbDangNhap.TabStop = false;
            // 
            // FormDangNhap
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 422);
            Controls.Add(gbDangNhap);
            Controls.Add(pBBackground);
            Margin = new Padding(2);
            Name = "FormDangNhap";
            Text = "FormDangNhap";
            ((System.ComponentModel.ISupportInitialize)pBBackground).EndInit();
            gbDangNhap.ResumeLayout(false);
            gbDangNhap.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.PictureBox pBBackground;
        private System.Windows.Forms.Label lbTenDangNhap;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.Label lbGioiThieu;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Button btnDangNhap;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.GroupBox gbDangNhap;
    }
}