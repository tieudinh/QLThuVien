﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormPhieuMuonUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPhieuMuonUser));
            dtGVPhieuMuon = new DataGridView();
            gbPhieuMuon = new GroupBox();
            txtTenSach = new TextBox();
            txtNguoiMuon = new TextBox();
            txtMaPhieu = new TextBox();
            lblMaPhieu = new Label();
            rbtnDaTra = new RadioButton();
            rbtnChuaTra = new RadioButton();
            lbTrangThai = new Label();
            dTPNgayTra = new DateTimePicker();
            lbNgayTra = new Label();
            dTPNgayMuon = new DateTimePicker();
            lbNgayMuon = new Label();
            lbTenSach = new Label();
            lbTenDocGia = new Label();
            ((System.ComponentModel.ISupportInitialize)dtGVPhieuMuon).BeginInit();
            gbPhieuMuon.SuspendLayout();
            SuspendLayout();
            // 
            // dtGVPhieuMuon
            // 
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.DarkSlateGray;
            dataGridViewCellStyle3.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dataGridViewCellStyle3.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle3.SelectionBackColor = Color.Teal;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dtGVPhieuMuon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dtGVPhieuMuon.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.Font = new Font("Tahoma", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = Color.DarkCyan;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            dtGVPhieuMuon.DefaultCellStyle = dataGridViewCellStyle4;
            dtGVPhieuMuon.Location = new Point(23, 239);
            dtGVPhieuMuon.Name = "dtGVPhieuMuon";
            dtGVPhieuMuon.RowHeadersWidth = 51;
            dtGVPhieuMuon.RowTemplate.Height = 24;
            dtGVPhieuMuon.Size = new Size(734, 275);
            dtGVPhieuMuon.TabIndex = 7;
            dtGVPhieuMuon.RowHeaderMouseClick += dtGVPhieuMuon_RowHeaderMouseClick;
            // 
            // gbPhieuMuon
            // 
            gbPhieuMuon.BackColor = SystemColors.ButtonFace;
            gbPhieuMuon.Controls.Add(txtTenSach);
            gbPhieuMuon.Controls.Add(txtNguoiMuon);
            gbPhieuMuon.Controls.Add(txtMaPhieu);
            gbPhieuMuon.Controls.Add(lblMaPhieu);
            gbPhieuMuon.Controls.Add(rbtnDaTra);
            gbPhieuMuon.Controls.Add(rbtnChuaTra);
            gbPhieuMuon.Controls.Add(lbTrangThai);
            gbPhieuMuon.Controls.Add(dTPNgayTra);
            gbPhieuMuon.Controls.Add(lbNgayTra);
            gbPhieuMuon.Controls.Add(dTPNgayMuon);
            gbPhieuMuon.Controls.Add(lbNgayMuon);
            gbPhieuMuon.Controls.Add(lbTenSach);
            gbPhieuMuon.Controls.Add(lbTenDocGia);
            gbPhieuMuon.Location = new Point(23, 11);
            gbPhieuMuon.Name = "gbPhieuMuon";
            gbPhieuMuon.Size = new Size(430, 222);
            gbPhieuMuon.TabIndex = 6;
            gbPhieuMuon.TabStop = false;
            // 
            // txtTenSach
            // 
            txtTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTenSach.Location = new Point(135, 80);
            txtTenSach.Name = "txtTenSach";
            txtTenSach.ReadOnly = true;
            txtTenSach.Size = new Size(277, 20);
            txtTenSach.TabIndex = 26;
            // 
            // txtNguoiMuon
            // 
            txtNguoiMuon.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtNguoiMuon.Location = new Point(135, 48);
            txtNguoiMuon.Name = "txtNguoiMuon";
            txtNguoiMuon.ReadOnly = true;
            txtNguoiMuon.Size = new Size(277, 20);
            txtNguoiMuon.TabIndex = 25;
            // 
            // txtMaPhieu
            // 
            txtMaPhieu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMaPhieu.Location = new Point(135, 16);
            txtMaPhieu.Name = "txtMaPhieu";
            txtMaPhieu.ReadOnly = true;
            txtMaPhieu.Size = new Size(277, 20);
            txtMaPhieu.TabIndex = 24;
            // 
            // lblMaPhieu
            // 
            lblMaPhieu.AutoSize = true;
            lblMaPhieu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblMaPhieu.Location = new Point(26, 19);
            lblMaPhieu.Name = "lblMaPhieu";
            lblMaPhieu.Size = new Size(58, 13);
            lblMaPhieu.TabIndex = 23;
            lblMaPhieu.Text = "Mã phiếu";
            // 
            // rbtnDaTra
            // 
            rbtnDaTra.AutoSize = true;
            rbtnDaTra.Enabled = false;
            rbtnDaTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnDaTra.Location = new Point(320, 191);
            rbtnDaTra.Name = "rbtnDaTra";
            rbtnDaTra.Size = new Size(61, 17);
            rbtnDaTra.TabIndex = 12;
            rbtnDaTra.TabStop = true;
            rbtnDaTra.Text = "Đã trả";
            rbtnDaTra.UseVisualStyleBackColor = true;
            // 
            // rbtnChuaTra
            // 
            rbtnChuaTra.AutoSize = true;
            rbtnChuaTra.Enabled = false;
            rbtnChuaTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnChuaTra.Location = new Point(135, 191);
            rbtnChuaTra.Name = "rbtnChuaTra";
            rbtnChuaTra.Size = new Size(74, 17);
            rbtnChuaTra.TabIndex = 11;
            rbtnChuaTra.TabStop = true;
            rbtnChuaTra.Text = "Chưa trả";
            rbtnChuaTra.UseVisualStyleBackColor = true;
            // 
            // lbTrangThai
            // 
            lbTrangThai.AutoSize = true;
            lbTrangThai.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTrangThai.Location = new Point(26, 189);
            lbTrangThai.Name = "lbTrangThai";
            lbTrangThai.Size = new Size(65, 13);
            lbTrangThai.TabIndex = 10;
            lbTrangThai.Text = "Tình trạng";
            // 
            // dTPNgayTra
            // 
            dTPNgayTra.CalendarFont = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayTra.Enabled = false;
            dTPNgayTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayTra.Location = new Point(135, 145);
            dTPNgayTra.Name = "dTPNgayTra";
            dTPNgayTra.Size = new Size(277, 20);
            dTPNgayTra.TabIndex = 9;
            // 
            // lbNgayTra
            // 
            lbNgayTra.AutoSize = true;
            lbNgayTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNgayTra.Location = new Point(26, 151);
            lbNgayTra.Name = "lbNgayTra";
            lbNgayTra.Size = new Size(55, 13);
            lbNgayTra.TabIndex = 8;
            lbNgayTra.Text = "Ngày trả";
            // 
            // dTPNgayMuon
            // 
            dTPNgayMuon.CalendarFont = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayMuon.Enabled = false;
            dTPNgayMuon.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayMuon.Location = new Point(135, 113);
            dTPNgayMuon.Name = "dTPNgayMuon";
            dTPNgayMuon.Size = new Size(277, 20);
            dTPNgayMuon.TabIndex = 7;
            // 
            // lbNgayMuon
            // 
            lbNgayMuon.AutoSize = true;
            lbNgayMuon.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNgayMuon.Location = new Point(26, 119);
            lbNgayMuon.Name = "lbNgayMuon";
            lbNgayMuon.Size = new Size(71, 13);
            lbNgayMuon.TabIndex = 6;
            lbNgayMuon.Text = "Ngày mượn";
            // 
            // lbTenSach
            // 
            lbTenSach.AutoSize = true;
            lbTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenSach.Location = new Point(26, 83);
            lbTenSach.Name = "lbTenSach";
            lbTenSach.Size = new Size(57, 13);
            lbTenSach.TabIndex = 4;
            lbTenSach.Text = "Tên sách";
            // 
            // lbTenDocGia
            // 
            lbTenDocGia.AutoSize = true;
            lbTenDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenDocGia.Location = new Point(26, 51);
            lbTenDocGia.Name = "lbTenDocGia";
            lbTenDocGia.Size = new Size(75, 13);
            lbTenDocGia.TabIndex = 2;
            lbTenDocGia.Text = "Người mượn";
            // 
            // FormPhieuMuonUser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(776, 528);
            Controls.Add(dtGVPhieuMuon);
            Controls.Add(gbPhieuMuon);
            Name = "FormPhieuMuonUser";
            Text = "FormPhieuMuonUser";
            Load += FormPhieuMuonUser_Load;
            ((System.ComponentModel.ISupportInitialize)dtGVPhieuMuon).EndInit();
            gbPhieuMuon.ResumeLayout(false);
            gbPhieuMuon.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataGridView dtGVPhieuMuon;
        private System.Windows.Forms.GroupBox gbPhieuMuon;
        private System.Windows.Forms.RadioButton rbtnDaTra;
        private System.Windows.Forms.RadioButton rbtnChuaTra;
        private System.Windows.Forms.Label lbTrangThai;
        private System.Windows.Forms.DateTimePicker dTPNgayTra;
        private System.Windows.Forms.Label lbNgayTra;
        private System.Windows.Forms.DateTimePicker dTPNgayMuon;
        private System.Windows.Forms.Label lbNgayMuon;
        private System.Windows.Forms.Label lbTenSach;
        private System.Windows.Forms.Label lbTenDocGia;
        private TextBox txtMaPhieu;
        private Label lblMaPhieu;
        private TextBox txtTenSach;
        private TextBox txtNguoiMuon;
    }
}