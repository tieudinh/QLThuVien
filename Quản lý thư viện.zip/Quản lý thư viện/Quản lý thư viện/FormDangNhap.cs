﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLTV_DTO;
using QLTV_DAO;
using QLTV_BUS;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormDangNhap : Form
    {
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có muốn thoát khỏi chương trình hay không", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            {
                if (dr == DialogResult.Yes)
                {
                    this.Close();

                }
            }
        }

        private void llbDangKi_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string tdn = txtTenDangNhap.Text;
            string mk = txtPass.Text;

            if (string.IsNullOrEmpty(tdn) || string.IsNullOrEmpty(mk))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Class_TaiKhoan taiKhoan = TaiKhoan_BUS.DangNhap(tdn, mk);

                if (taiKhoan != null)
                {
                    MessageBox.Show($"Đăng nhập thành công!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (taiKhoan.VaiTro == 1)
                    {
                        // Chuyển sang giao diện chính
                        this.Hide();
                        FormAdmin formMain = new FormAdmin();
                        formMain.Show();
                    }
                    else if (taiKhoan.VaiTro == 0)
                    {
                        this.Hide();
                        FormUser formUser = new FormUser();
                        formUser.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Có lỗi xảy ra: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
