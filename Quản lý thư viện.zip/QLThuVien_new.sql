﻿create database QLThuVien

use QLThuVien

create table Sach(
MaSach nchar(10) primary key not null,
TenSach nvarchar(255),
TacGia nvarchar(255),
TheLoai nvarchar(255),
NhaXuatBan nvarchar(255),
GiaSach int,
TinhTrang nvarchar(255))


create table DocGia(
MaDocGia nchar(10) primary key not null,
TenDangNhap nchar(10) unique,
HoTen nvarchar(255),
GioiTinh nvarchar(10),
NamSinh int,
DiaChi nvarchar(255),
SDT nvarchar(255))

create table TaiKhoan(
MaDocGia nchar(10) foreign key (MaDocGia) references DocGia(MaDocGia) on delete cascade,
TenDangNhap nchar(10) not null unique,
MatKhau nchar(10) not null unique,
VaiTro int)

create table PhieuMuon(
MaPhieu nchar(10) primary key not null,
MaDocGia nchar(10) foreign key (MaDocGia) references DocGia(MaDocGia) on delete cascade,
MaSach nchar(10) foreign key (MaSach) references Sach(MaSach) on delete cascade,
NgayMuon datetime,
NgayPhaiTra datetime)

create table PhieuTra(
MaPhieu nchar(10) primary key not null,
MaDocGia nchar(10) foreign key (MaDocGia) references DocGia(MaDocGia) on delete cascade,
MaSach nchar(10) foreign key (MaSach) references Sach(MaSach) on delete cascade,
NgayTra datetime)

insert into PhieuMuon(MaPhieu, MaDocGia, MaSach, NgayMuon, NgayPhaiTra) values
('1', 'user1', '1', '2024-12-20', '2024-12-25'),
('2', 'user1', '1', '2024-12-10', '2024-12-20'),
('3', 'user1', '1', '2024-12-20', '2024-12-30'),
('4', 'user2', '1', '2024-12-20', '2024-12-30'),
('5', 'user2', '1', '2024-12-15', '2024-12-25');

insert into PhieuTra(MaPhieu, MaDocGia, MaSach,NgayTra) values
('1', 'user1', '1','2024-12-30'),
('2', 'user1', '1', '2024-12-20'),
('3', 'user1', '1', '2024-12-30'),
('4', 'user2', '1', '2024-12-30'),
('5', 'user2', '1', '2024-12-30');

select MAX(MaPhieu) from PhieuMuon
select * from TaiKhoan
select * from DocGia
select * from DocGia where MaDocGia like 'user%'
select * from DocGia where MaDocGia = 'user1'
select * from PhieuMuon
select * from PhieuTra
insert into TaiKhoan values
	('admin', 'Admin_real', 'admin1234', '1'),
	('user1', 'khanhthh', '11111111', '0');

select MAX(MaDocGia) from DocGia
SELECT MAX(CAST(SUBSTRING(MaDocGia, 5, LEN(MaDocGia) - 4) AS INT)) FROM DocGia WHERE MaDocGia LIKE 'user%'

insert into DocGia values
	('admin', 'Admin_real', 'Trinh Tran Diem Huong', 'Nu', 2004, 'Ho Chi Minh', '0346662715'),
	('user1', 'khanhthh', 'Tang Huynh Huu Khanh', 'Nam', 2004, 'Ho Chi Minh', '');

select * from Sach
select MAX(MaSach) from Sach
insert into Sach values
	('1', 'Chuyện con mèo dạy hải âu bay', 'Luis Sepúlveda', 'Hư cấu', 'Văn học', 20000, 'CHUAMUON');

SELECT * FROM DocGia WHERE HoTen LIKE N'%' + 'như' + '%'
SELECT *
FROM TaiKhoan 
WHERE MaDocGia IN (SELECT MaDocGia FROM TaiKhoan)

SELECT * FROM TaiKhoan WHERE TenDangNhap = 'Admin_real' AND MatKhau = 'admin1234'