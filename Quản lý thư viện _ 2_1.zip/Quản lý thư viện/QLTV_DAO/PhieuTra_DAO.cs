﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using QLTV_DTO;

namespace QLTV_DAO
{
    public class PhieuTra_DAO
    {
        public static List<Class_PhieuTra> layDSPhieuTra()
        {
            List<Class_PhieuTra> dsPT = new List<Class_PhieuTra>();
            DataTable dt = DataProvider.TruyVan_LayDuLieu("select * from PhieuTra");

            foreach (DataRow dr in dt.Rows)
            {
                Class_PhieuTra pt = new Class_PhieuTra();

                pt.MaPhieu = dr["MaPhieu"].ToString();
                pt.MaDocGia = dr["MaDocGia"].ToString();
                pt.MaSach = dr["MaSach"].ToString();
                pt.NgayTra = DateTime.Parse(dr["NgayTra"].ToString());

                dsPT.Add(pt);
            }

            return dsPT;
        }

        public static void themPT(Class_PhieuTra pt)
        {
            string query = "insert into PhieuTra(MaPhieu, MaDocGia, MaSach, NgayTra) values (@MaPhieu, @MaDocGia, @MaSach, @NgayTra)";
            SqlParameter[] sp = new SqlParameter[4];

            sp[0] = new SqlParameter("MaPhieu", pt.MaPhieu);
            sp[1] = new SqlParameter("MaDocGia", pt.MaDocGia);
            sp[2] = new SqlParameter("MaSach", pt.MaSach);
            sp[3] = new SqlParameter("NgayTra", pt.NgayTra);

            DataProvider.ExcuteNonQuery(query, CommandType.Text, sp);
        }

        public static List<Class_PhieuTra> timKiemPT_DocGia(string lok)
        {
            List<Class_PhieuTra> dsPT = new List<Class_PhieuTra>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM PhieuTra WHERE MaDocGia LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_PhieuTra pm = new Class_PhieuTra();

                pm.MaPhieu = dr["MaPhieu"].ToString();
                pm.MaDocGia = dr["MaDocGia"].ToString();
                pm.MaSach = dr["MaSach"].ToString();
                pm.NgayTra = DateTime.Parse(dr["NgayTra"].ToString());

                dsPT.Add(pm);
            }

            return dsPT;
        }

        public static List<Class_PhieuTra> timKiemPT_Sach(string lok)
        {
            List<Class_PhieuTra> dsPT = new List<Class_PhieuTra>();
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("Ten", lok);

            DataTable dt = DataProvider.SelectData("SELECT * FROM PhieuTra WHERE MaSach LIKE N'%' + @Ten + '%'", CommandType.Text, sp);
            foreach (DataRow dr in dt.Rows)
            {
                Class_PhieuTra pm = new Class_PhieuTra();

                pm.MaPhieu = dr["MaPhieu"].ToString();
                pm.MaDocGia = dr["MaDocGia"].ToString();
                pm.MaSach = dr["MaSach"].ToString();
                pm.NgayTra = DateTime.Parse(dr["NgayTra"].ToString());

                dsPT.Add(pm);
            }

            return dsPT;
        }
    }
}
