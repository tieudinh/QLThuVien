﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLTV_DTO
{
    public class Class_TaiKhoan
    {
        public string MaDocGia { get; set; }
        public string TenDangNhap { get; set; }
        public string MatKhau { get; set; }
        public int VaiTro { get; set; }
    }
}
