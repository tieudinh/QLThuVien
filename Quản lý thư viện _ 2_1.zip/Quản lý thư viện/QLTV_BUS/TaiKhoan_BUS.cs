﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLTV_DAO;
using QLTV_DTO;

namespace QLTV_BUS
{
    public class TaiKhoan_BUS
    {
        public static List<Class_TaiKhoan> layDSTaiKhoan()
        {
            return TaiKhoan_DAO.layDSTaiKhoan();
        }

        public static Class_TaiKhoan DangNhap(string tenDangNhap, string matKhau)
        {
            Class_TaiKhoan taiKhoan = TaiKhoan_DAO.DangNhap(tenDangNhap, matKhau);

            if (taiKhoan != null)
            {
                return taiKhoan;
            }

            return null;
        }

        public static bool themTK(Class_TaiKhoan tk)
        {
            try
            {
                TaiKhoan_DAO.themTK(tk);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool xoaTK(string tk)
        {
            try
            {
                TaiKhoan_DAO.xoaTK(tk);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool suaTK(Class_TaiKhoan tk)
        {
            try
            {
                TaiKhoan_DAO.suaTK(tk);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<Class_TaiKhoan> timKiemDG_MaDocGia(string lok)
        {
            return TaiKhoan_DAO.timKiemTK_MaDocGia(lok);
        }

        public static List<Class_TaiKhoan> timKiemDG_TenDangNhap(string lok)
        {
            return TaiKhoan_DAO.timKiemTK_TenDangNhap(lok);
        }
    }
}
