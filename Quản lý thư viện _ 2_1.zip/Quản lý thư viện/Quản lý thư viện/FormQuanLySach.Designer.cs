﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormQuanLySach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormQuanLySach));
            panel1 = new Panel();
            panel_TimKiem = new Panel();
            btnTimKiem = new Button();
            txtTimKiem = new TextBox();
            rbtnTinhTrang = new RadioButton();
            rbtnNXB = new RadioButton();
            rbtnTenSach = new RadioButton();
            rbtnTheLoai = new RadioButton();
            rbtnTacGia = new RadioButton();
            rbtnMaSach = new RadioButton();
            lbGioiThieu = new Label();
            panel_ThongTin = new Panel();
            txtTinhTrang = new TextBox();
            txtTheLoai = new TextBox();
            btnSua = new Button();
            btnXoa = new Button();
            btnThem = new Button();
            lbTinhTrang = new Label();
            txtGiaSach = new TextBox();
            lbGiaSach = new Label();
            txtNXB = new TextBox();
            lbNXB = new Label();
            lbTheLoai = new Label();
            txtTacGia = new TextBox();
            lbTacGia = new Label();
            txtTenSach = new TextBox();
            lbTenSach = new Label();
            txtMaSach = new TextBox();
            lbMaSach = new Label();
            panel_DS = new Panel();
            dtGVSach = new DataGridView();
            panel1.SuspendLayout();
            panel_TimKiem.SuspendLayout();
            panel_ThongTin.SuspendLayout();
            panel_DS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtGVSach).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackgroundImage = (Image)resources.GetObject("panel1.BackgroundImage");
            panel1.Controls.Add(panel_TimKiem);
            panel1.Controls.Add(panel_ThongTin);
            panel1.Controls.Add(panel_DS);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(634, 613);
            panel1.TabIndex = 0;
            // 
            // panel_TimKiem
            // 
            panel_TimKiem.BackColor = SystemColors.ButtonFace;
            panel_TimKiem.Controls.Add(btnTimKiem);
            panel_TimKiem.Controls.Add(txtTimKiem);
            panel_TimKiem.Controls.Add(rbtnTinhTrang);
            panel_TimKiem.Controls.Add(rbtnNXB);
            panel_TimKiem.Controls.Add(rbtnTenSach);
            panel_TimKiem.Controls.Add(rbtnTheLoai);
            panel_TimKiem.Controls.Add(rbtnTacGia);
            panel_TimKiem.Controls.Add(rbtnMaSach);
            panel_TimKiem.Controls.Add(lbGioiThieu);
            panel_TimKiem.Location = new Point(341, 11);
            panel_TimKiem.Name = "panel_TimKiem";
            panel_TimKiem.Size = new Size(284, 290);
            panel_TimKiem.TabIndex = 8;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnTimKiem.Location = new Point(24, 239);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(232, 31);
            btnTimKiem.TabIndex = 21;
            btnTimKiem.Text = "Tìm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTimKiem.Location = new Point(24, 33);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(232, 20);
            txtTimKiem.TabIndex = 21;
            // 
            // rbtnTinhTrang
            // 
            rbtnTinhTrang.AutoSize = true;
            rbtnTinhTrang.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnTinhTrang.ForeColor = SystemColors.ActiveCaptionText;
            rbtnTinhTrang.Location = new Point(157, 176);
            rbtnTinhTrang.Name = "rbtnTinhTrang";
            rbtnTinhTrang.Size = new Size(83, 17);
            rbtnTinhTrang.TabIndex = 27;
            rbtnTinhTrang.TabStop = true;
            rbtnTinhTrang.Text = "Tình trạng";
            rbtnTinhTrang.UseVisualStyleBackColor = true;
            // 
            // rbtnNXB
            // 
            rbtnNXB.AutoSize = true;
            rbtnNXB.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnNXB.ForeColor = SystemColors.ActiveCaptionText;
            rbtnNXB.Location = new Point(157, 122);
            rbtnNXB.Name = "rbtnNXB";
            rbtnNXB.Size = new Size(99, 17);
            rbtnNXB.TabIndex = 26;
            rbtnNXB.TabStop = true;
            rbtnNXB.Text = "Nhà xuất bản";
            rbtnNXB.UseVisualStyleBackColor = true;
            // 
            // rbtnTenSach
            // 
            rbtnTenSach.AutoSize = true;
            rbtnTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnTenSach.ForeColor = SystemColors.ActiveCaptionText;
            rbtnTenSach.Location = new Point(157, 67);
            rbtnTenSach.Name = "rbtnTenSach";
            rbtnTenSach.Size = new Size(75, 17);
            rbtnTenSach.TabIndex = 25;
            rbtnTenSach.TabStop = true;
            rbtnTenSach.Text = "Tên sách";
            rbtnTenSach.UseVisualStyleBackColor = true;
            // 
            // rbtnTheLoai
            // 
            rbtnTheLoai.AutoSize = true;
            rbtnTheLoai.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnTheLoai.ForeColor = SystemColors.ActiveCaptionText;
            rbtnTheLoai.Location = new Point(24, 176);
            rbtnTheLoai.Name = "rbtnTheLoai";
            rbtnTheLoai.Size = new Size(69, 17);
            rbtnTheLoai.TabIndex = 24;
            rbtnTheLoai.TabStop = true;
            rbtnTheLoai.Text = "Thể loại";
            rbtnTheLoai.UseVisualStyleBackColor = true;
            // 
            // rbtnTacGia
            // 
            rbtnTacGia.AutoSize = true;
            rbtnTacGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnTacGia.ForeColor = SystemColors.ActiveCaptionText;
            rbtnTacGia.Location = new Point(24, 122);
            rbtnTacGia.Name = "rbtnTacGia";
            rbtnTacGia.Size = new Size(65, 17);
            rbtnTacGia.TabIndex = 23;
            rbtnTacGia.TabStop = true;
            rbtnTacGia.Text = "Tác giả";
            rbtnTacGia.UseVisualStyleBackColor = true;
            // 
            // rbtnMaSach
            // 
            rbtnMaSach.AutoSize = true;
            rbtnMaSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnMaSach.ForeColor = SystemColors.ActiveCaptionText;
            rbtnMaSach.Location = new Point(24, 67);
            rbtnMaSach.Name = "rbtnMaSach";
            rbtnMaSach.Size = new Size(71, 17);
            rbtnMaSach.TabIndex = 22;
            rbtnMaSach.TabStop = true;
            rbtnMaSach.Text = "Mã sách";
            rbtnMaSach.UseVisualStyleBackColor = true;
            // 
            // lbGioiThieu
            // 
            lbGioiThieu.AutoSize = true;
            lbGioiThieu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbGioiThieu.ForeColor = SystemColors.ActiveCaptionText;
            lbGioiThieu.Location = new Point(11, 12);
            lbGioiThieu.Name = "lbGioiThieu";
            lbGioiThieu.Size = new Size(88, 13);
            lbGioiThieu.TabIndex = 21;
            lbGioiThieu.Text = "Tìm kiếm theo";
            // 
            // panel_ThongTin
            // 
            panel_ThongTin.BackColor = SystemColors.ButtonFace;
            panel_ThongTin.Controls.Add(txtTinhTrang);
            panel_ThongTin.Controls.Add(txtTheLoai);
            panel_ThongTin.Controls.Add(btnSua);
            panel_ThongTin.Controls.Add(btnXoa);
            panel_ThongTin.Controls.Add(btnThem);
            panel_ThongTin.Controls.Add(lbTinhTrang);
            panel_ThongTin.Controls.Add(txtGiaSach);
            panel_ThongTin.Controls.Add(lbGiaSach);
            panel_ThongTin.Controls.Add(txtNXB);
            panel_ThongTin.Controls.Add(lbNXB);
            panel_ThongTin.Controls.Add(lbTheLoai);
            panel_ThongTin.Controls.Add(txtTacGia);
            panel_ThongTin.Controls.Add(lbTacGia);
            panel_ThongTin.Controls.Add(txtTenSach);
            panel_ThongTin.Controls.Add(lbTenSach);
            panel_ThongTin.Controls.Add(txtMaSach);
            panel_ThongTin.Controls.Add(lbMaSach);
            panel_ThongTin.Location = new Point(10, 11);
            panel_ThongTin.Name = "panel_ThongTin";
            panel_ThongTin.Size = new Size(326, 290);
            panel_ThongTin.TabIndex = 7;
            // 
            // txtTinhTrang
            // 
            txtTinhTrang.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTinhTrang.Location = new Point(120, 175);
            txtTinhTrang.Name = "txtTinhTrang";
            txtTinhTrang.Size = new Size(193, 20);
            txtTinhTrang.TabIndex = 22;
            // 
            // txtTheLoai
            // 
            txtTheLoai.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTheLoai.Location = new Point(120, 94);
            txtTheLoai.Name = "txtTheLoai";
            txtTheLoai.Size = new Size(193, 20);
            txtTheLoai.TabIndex = 21;
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua.Location = new Point(247, 239);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(66, 31);
            btnSua.TabIndex = 20;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa.Location = new Point(130, 239);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(66, 31);
            btnXoa.TabIndex = 19;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem.Location = new Point(18, 239);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(66, 31);
            btnThem.TabIndex = 18;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // lbTinhTrang
            // 
            lbTinhTrang.AutoSize = true;
            lbTinhTrang.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTinhTrang.ForeColor = SystemColors.ActiveCaptionText;
            lbTinhTrang.Location = new Point(19, 178);
            lbTinhTrang.Name = "lbTinhTrang";
            lbTinhTrang.Size = new Size(65, 13);
            lbTinhTrang.TabIndex = 16;
            lbTinhTrang.Text = "Tình trạng";
            // 
            // txtGiaSach
            // 
            txtGiaSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtGiaSach.Location = new Point(120, 148);
            txtGiaSach.Name = "txtGiaSach";
            txtGiaSach.Size = new Size(193, 20);
            txtGiaSach.TabIndex = 15;
            // 
            // lbGiaSach
            // 
            lbGiaSach.AutoSize = true;
            lbGiaSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbGiaSach.ForeColor = SystemColors.ActiveCaptionText;
            lbGiaSach.Location = new Point(19, 151);
            lbGiaSach.Name = "lbGiaSach";
            lbGiaSach.Size = new Size(54, 13);
            lbGiaSach.TabIndex = 14;
            lbGiaSach.Text = "Giá sách";
            // 
            // txtNXB
            // 
            txtNXB.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtNXB.Location = new Point(120, 122);
            txtNXB.Name = "txtNXB";
            txtNXB.Size = new Size(193, 20);
            txtNXB.TabIndex = 11;
            // 
            // lbNXB
            // 
            lbNXB.AutoSize = true;
            lbNXB.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNXB.ForeColor = SystemColors.ActiveCaptionText;
            lbNXB.Location = new Point(19, 125);
            lbNXB.Name = "lbNXB";
            lbNXB.Size = new Size(81, 13);
            lbNXB.TabIndex = 10;
            lbNXB.Text = "Nhà xuất bản";
            // 
            // lbTheLoai
            // 
            lbTheLoai.AutoSize = true;
            lbTheLoai.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTheLoai.ForeColor = SystemColors.ActiveCaptionText;
            lbTheLoai.Location = new Point(19, 97);
            lbTheLoai.Name = "lbTheLoai";
            lbTheLoai.Size = new Size(51, 13);
            lbTheLoai.TabIndex = 8;
            lbTheLoai.Text = "Thể loại";
            // 
            // txtTacGia
            // 
            txtTacGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTacGia.Location = new Point(120, 67);
            txtTacGia.Name = "txtTacGia";
            txtTacGia.Size = new Size(193, 20);
            txtTacGia.TabIndex = 7;
            // 
            // lbTacGia
            // 
            lbTacGia.AutoSize = true;
            lbTacGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTacGia.ForeColor = SystemColors.ActiveCaptionText;
            lbTacGia.Location = new Point(19, 70);
            lbTacGia.Name = "lbTacGia";
            lbTacGia.Size = new Size(47, 13);
            lbTacGia.TabIndex = 6;
            lbTacGia.Text = "Tác giả";
            // 
            // txtTenSach
            // 
            txtTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTenSach.Location = new Point(120, 40);
            txtTenSach.Name = "txtTenSach";
            txtTenSach.Size = new Size(193, 20);
            txtTenSach.TabIndex = 5;
            // 
            // lbTenSach
            // 
            lbTenSach.AutoSize = true;
            lbTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenSach.ForeColor = SystemColors.ActiveCaptionText;
            lbTenSach.Location = new Point(19, 42);
            lbTenSach.Name = "lbTenSach";
            lbTenSach.Size = new Size(57, 13);
            lbTenSach.TabIndex = 4;
            lbTenSach.Text = "Tên sách";
            // 
            // txtMaSach
            // 
            txtMaSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMaSach.Location = new Point(120, 12);
            txtMaSach.Name = "txtMaSach";
            txtMaSach.Size = new Size(193, 20);
            txtMaSach.TabIndex = 3;
            // 
            // lbMaSach
            // 
            lbMaSach.AutoSize = true;
            lbMaSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbMaSach.ForeColor = SystemColors.ActiveCaptionText;
            lbMaSach.Location = new Point(19, 15);
            lbMaSach.Name = "lbMaSach";
            lbMaSach.Size = new Size(53, 13);
            lbMaSach.TabIndex = 2;
            lbMaSach.Text = "Mã sách";
            // 
            // panel_DS
            // 
            panel_DS.Controls.Add(dtGVSach);
            panel_DS.Location = new Point(10, 307);
            panel_DS.Name = "panel_DS";
            panel_DS.Size = new Size(614, 295);
            panel_DS.TabIndex = 6;
            // 
            // dtGVSach
            // 
            dtGVSach.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtGVSach.Dock = DockStyle.Fill;
            dtGVSach.Location = new Point(0, 0);
            dtGVSach.Name = "dtGVSach";
            dtGVSach.RowHeadersWidth = 51;
            dtGVSach.RowTemplate.Height = 24;
            dtGVSach.Size = new Size(614, 295);
            dtGVSach.TabIndex = 0;
            dtGVSach.RowHeaderMouseClick += dtGVSach_RowHeaderMouseClick;
            // 
            // FormQuanLySach
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(634, 613);
            Controls.Add(panel1);
            Name = "FormQuanLySach";
            Text = "FormQuanLySach";
            Load += FormQuanLySach_Load;
            panel1.ResumeLayout(false);
            panel_TimKiem.ResumeLayout(false);
            panel_TimKiem.PerformLayout();
            panel_ThongTin.ResumeLayout(false);
            panel_ThongTin.PerformLayout();
            panel_DS.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtGVSach).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_TimKiem;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.RadioButton rbtnTinhTrang;
        private System.Windows.Forms.RadioButton rbtnNXB;
        private System.Windows.Forms.RadioButton rbtnTenSach;
        private System.Windows.Forms.RadioButton rbtnTheLoai;
        private System.Windows.Forms.RadioButton rbtnTacGia;
        private System.Windows.Forms.RadioButton rbtnMaSach;
        private System.Windows.Forms.Label lbGioiThieu;
        private System.Windows.Forms.Panel panel_ThongTin;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Label lbTinhTrang;
        private System.Windows.Forms.TextBox txtGiaSach;
        private System.Windows.Forms.Label lbGiaSach;
        private System.Windows.Forms.TextBox txtNXB;
        private System.Windows.Forms.Label lbNXB;
        private System.Windows.Forms.Label lbTheLoai;
        private System.Windows.Forms.TextBox txtTacGia;
        private System.Windows.Forms.Label lbTacGia;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.Label lbTenSach;
        private System.Windows.Forms.TextBox txtMaSach;
        private System.Windows.Forms.Label lbMaSach;
        private System.Windows.Forms.Panel panel_DS;
        private System.Windows.Forms.DataGridView dtGVSach;
        private TextBox txtTinhTrang;
        private TextBox txtTheLoai;
    }
}