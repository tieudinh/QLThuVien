﻿using QLTV_BUS;
using QLTV_DAO;
using QLTV_DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormQuanLyPhieuMuon : Form
    {
        public FormQuanLyPhieuMuon()
        {
            InitializeComponent();
        }

        private void lbTenDocGia_Click(object sender, EventArgs e)
        {

        }

        private void lbTenSach_Click(object sender, EventArgs e)
        {

        }

        private void cbReader_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbBook_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dTPNgayMuon_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dTPNgayTra_ValueChanged(object sender, EventArgs e)
        {

        }

        private void lbNgayMuon_Click(object sender, EventArgs e)
        {

        }

        private void lbNgayTra_Click(object sender, EventArgs e)
        {

        }

        private void gbPhieuMuon_Enter(object sender, EventArgs e)
        {

        }

        private void lbTrangThai_Click(object sender, EventArgs e)
        {

        }

        private void rbtnChuaTra_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnDaTra_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                Class_PhieuMuon pm = new Class_PhieuMuon();

                pm.MaPhieu = txtMaPhieu.Text;
                pm.MaDocGia = cbReader.SelectedValue.ToString();
                pm.MaSach = cbBook.SelectedValue.ToString();
                pm.NgayMuon = dTPNgayMuon.Value;
                pm.NgayPhaiTra = dTPNgayTra.Value;

                PhieuMuon_BUS.suaPM(pm);
                MessageBox.Show("Thêm phiếu mượn thành công!", "Thông báo", MessageBoxButtons.OK);

                loadDSPhieuMuon();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void loadDSPhieuMuon()
        {
            dtGVPhieuMuon.DataSource = PhieuMuon_DAO.layDSPhieuMuon();
        }

        private void FormQuanLyPhieuMuon_Load(object sender, EventArgs e)
        {
            cbReader.DataSource = DocGia_BUS.LayDSDocGia();
            cbReader.DisplayMember = "HoTen";
            cbReader.ValueMember = "MaDocGia";
            cbReader.SelectedValue = -1;
            //cbReader.SelectedIndexChanged += new EventHandler(cbBook_SelectedIndexChanged);

            cbBook.DataSource = Sach_BUS.layDSSach();
            cbBook.DisplayMember = "TenSach";
            cbBook.ValueMember = "MaSach";
            cbBook.SelectedValue = -1;

            loadDSPhieuMuon();
        }

        private void dtGVPhieuMuon_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtMaPhieu.Text = dtGVPhieuMuon.Rows[e.RowIndex].Cells[0].Value.ToString();
            dTPNgayMuon.Text = dtGVPhieuMuon.Rows[e.RowIndex].Cells[3].Value.ToString();
            dTPNgayTra.Text = dtGVPhieuMuon.Rows[e.RowIndex].Cells[4].Value.ToString();

            //cbBook.Text = dtGVPhieuMuon.Rows[e.RowIndex].Cells[2].Value.ToString();
            //cbReader.Text = dtGVPhieuMuon.Rows[e.RowIndex].Cells[1].Value.ToString();

            string maDG = dtGVPhieuMuon.Rows[e.RowIndex].Cells[1].Value.ToString();
            foreach (var item in cbReader.Items)
            {
                if (item is Class_DocGia dg && dg.MaDocGia == maDG)
                {
                    cbReader.Text = dg.HoTen;
                    break;
                }
            }

            string maS = dtGVPhieuMuon.Rows[e.RowIndex].Cells[2].Value.ToString();
            foreach (var item in cbReader.Items)
            {
                if (item is Class_Sach sach && sach.MaSach == maS)
                {
                    cbBook.Text = sach.MaSach;
                    break;
                }
            }
        }

        private string getNewMaPhieu()
        {
            string query = "select MAX(MaPhieu) from PhieuMuon";

            object result = DataProvider.ExecuteScalar(query);

            if (result == DBNull.Value || result == null)
            {
                return "0";
            }
            else
            {
                int maxNumber = int.Parse(result.ToString());
                maxNumber++;
                return "PM" + maxNumber.ToString();
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                Class_PhieuMuon pm = new Class_PhieuMuon();

                pm.MaPhieu = getNewMaPhieu();
                pm.MaDocGia = cbReader.SelectedValue.ToString();
                pm.MaSach = cbBook.SelectedValue.ToString();
                pm.NgayMuon = dTPNgayMuon.Value;
                pm.NgayPhaiTra = dTPNgayTra.Value;

                PhieuMuon_BUS.themPM(pm);
                MessageBox.Show("Thêm phiếu mượn thành công!", "Thông báo", MessageBoxButtons.OK);

                loadDSPhieuMuon();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dtGVPhieuMuon.SelectedRows.Count > 0)
            {
                string maPhieu = dtGVPhieuMuon.SelectedRows[0].Cells[0].Value.ToString();

                DialogResult result = MessageBox.Show(
                    "Bạn có chắc chắn muốn xóa độc giả có mã [" + maPhieu + "] ?",
                    "Xác nhận xóa",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        DocGia_BUS.xoaDG(maPhieu);

                        MessageBox.Show("Xóa phiếu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        loadDSPhieuMuon();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Đã xảy ra lỗi khi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn phiếu để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (rbtnNguoiMuon.Checked == true)
                dtGVPhieuMuon.DataSource = PhieuMuon_BUS.timKiemPM_DocGia(txtTimKiem.Text);
            else if (rbtnTenSach.Checked == true)
                dtGVPhieuMuon.DataSource = PhieuMuon_BUS.timKiemPM_Sach(txtTimKiem.Text);   
        }
    }
}
