﻿using QLTV_DTO;
using QLTV_DAO;
using QLTV_BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormTaiKhoanUser : Form
    {
        public string ReceiveID { get; set; }
        public FormTaiKhoanUser()
        {
            InitializeComponent();
        }

        private void loadTTDocGia()
        {
            Class_DocGia dg = DocGia_DAO.layTTDocGia(ReceiveID);

            txtMaDocGia.Text = dg.MaDocGia;
            txtTenDangNhap.Text = dg.TenDangNhap;
            txtHoTen.Text = dg.HoTen;

            if (dg.GioiTinh == "Nam")
                rbtnNam.Checked = true;
            else if (dg.GioiTinh == "Nu" || dg.GioiTinh == "Nữ")
                rbtnNu.Checked = true;

            txtNamSinh.Text = dg.NamSinh.ToString();
            txtDiaChi.Text = dg.DiaChi;
            txtSDT.Text = dg.SDT;
        }

        private void FormTaiKhoanUser_Load(object sender, EventArgs e)
        {
            loadTTDocGia();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                Class_DocGia dg = new Class_DocGia();

                dg.MaDocGia = txtMaDocGia.Text;
                dg.TenDangNhap = txtTenDangNhap.Text.Trim();
                dg.HoTen = txtHoTen.Text.Trim();
                dg.DiaChi = txtDiaChi.Text.Trim();

                //dg.GioiTinh = txtGioiTinh.Text.Trim();
                if (rbtnNam.Checked == true)
                {
                    dg.GioiTinh = "Nam";
                }
                else if (rbtnNu.Checked == true)
                {
                    dg.GioiTinh = "Nữ";
                }

                dg.NamSinh = int.Parse(txtNamSinh.Text.Trim());
                dg.SDT = txtSDT.Text.Trim();

                DocGia_BUS.suaDG(dg);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
