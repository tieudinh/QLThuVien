﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormTaiKhoanUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTaiKhoanUser));
            txtDiaChi = new TextBox();
            lbDiaChi = new Label();
            txtNamSinh = new TextBox();
            lbNamSinh = new Label();
            rbtnNu = new RadioButton();
            rbtnNam = new RadioButton();
            lbGioiTinh = new Label();
            txtHoTen = new TextBox();
            lbHoTen = new Label();
            txtTenDangNhap = new TextBox();
            lbTenDangNhap = new Label();
            lbMaDocGia = new Label();
            panel_DocGia = new Panel();
            txtSDT = new TextBox();
            lblSDT = new Label();
            btnSua = new Button();
            txtMaDocGia = new TextBox();
            panel_DocGia.SuspendLayout();
            SuspendLayout();
            // 
            // txtDiaChi
            // 
            txtDiaChi.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtDiaChi.Location = new Point(104, 143);
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(207, 20);
            txtDiaChi.TabIndex = 12;
            // 
            // lbDiaChi
            // 
            lbDiaChi.AutoSize = true;
            lbDiaChi.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbDiaChi.Location = new Point(3, 146);
            lbDiaChi.Name = "lbDiaChi";
            lbDiaChi.Size = new Size(45, 13);
            lbDiaChi.TabIndex = 11;
            lbDiaChi.Text = "Địa chỉ";
            // 
            // txtNamSinh
            // 
            txtNamSinh.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtNamSinh.Location = new Point(104, 116);
            txtNamSinh.Name = "txtNamSinh";
            txtNamSinh.Size = new Size(207, 20);
            txtNamSinh.TabIndex = 10;
            // 
            // lbNamSinh
            // 
            lbNamSinh.AutoSize = true;
            lbNamSinh.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNamSinh.Location = new Point(3, 119);
            lbNamSinh.Name = "lbNamSinh";
            lbNamSinh.Size = new Size(58, 13);
            lbNamSinh.TabIndex = 9;
            lbNamSinh.Text = "Năm sinh";
            // 
            // rbtnNu
            // 
            rbtnNu.AutoSize = true;
            rbtnNu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnNu.Location = new Point(271, 92);
            rbtnNu.Name = "rbtnNu";
            rbtnNu.Size = new Size(40, 17);
            rbtnNu.TabIndex = 8;
            rbtnNu.TabStop = true;
            rbtnNu.Text = "Nữ";
            rbtnNu.UseVisualStyleBackColor = true;
            // 
            // rbtnNam
            // 
            rbtnNam.AutoSize = true;
            rbtnNam.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnNam.Location = new Point(104, 92);
            rbtnNam.Name = "rbtnNam";
            rbtnNam.Size = new Size(50, 17);
            rbtnNam.TabIndex = 7;
            rbtnNam.TabStop = true;
            rbtnNam.Text = "Nam";
            rbtnNam.UseVisualStyleBackColor = true;
            // 
            // lbGioiTinh
            // 
            lbGioiTinh.AutoSize = true;
            lbGioiTinh.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbGioiTinh.Location = new Point(3, 92);
            lbGioiTinh.Name = "lbGioiTinh";
            lbGioiTinh.Size = new Size(53, 13);
            lbGioiTinh.TabIndex = 6;
            lbGioiTinh.Text = "Giới tính";
            // 
            // txtHoTen
            // 
            txtHoTen.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtHoTen.Location = new Point(104, 62);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(207, 20);
            txtHoTen.TabIndex = 5;
            // 
            // lbHoTen
            // 
            lbHoTen.AutoSize = true;
            lbHoTen.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbHoTen.Location = new Point(3, 65);
            lbHoTen.Name = "lbHoTen";
            lbHoTen.Size = new Size(44, 13);
            lbHoTen.TabIndex = 4;
            lbHoTen.Text = "Họ tên";
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.Enabled = false;
            txtTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTenDangNhap.Location = new Point(104, 35);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.ReadOnly = true;
            txtTenDangNhap.Size = new Size(207, 20);
            txtTenDangNhap.TabIndex = 3;
            // 
            // lbTenDangNhap
            // 
            lbTenDangNhap.AutoSize = true;
            lbTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenDangNhap.Location = new Point(3, 38);
            lbTenDangNhap.Name = "lbTenDangNhap";
            lbTenDangNhap.Size = new Size(90, 13);
            lbTenDangNhap.TabIndex = 2;
            lbTenDangNhap.Text = "Tên đăng nhập";
            // 
            // lbMaDocGia
            // 
            lbMaDocGia.AutoSize = true;
            lbMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbMaDocGia.Location = new Point(3, 10);
            lbMaDocGia.Name = "lbMaDocGia";
            lbMaDocGia.Size = new Size(67, 13);
            lbMaDocGia.TabIndex = 0;
            lbMaDocGia.Text = "Mã độc giả";
            // 
            // panel_DocGia
            // 
            panel_DocGia.Controls.Add(txtSDT);
            panel_DocGia.Controls.Add(lblSDT);
            panel_DocGia.Controls.Add(btnSua);
            panel_DocGia.Controls.Add(txtDiaChi);
            panel_DocGia.Controls.Add(lbDiaChi);
            panel_DocGia.Controls.Add(txtNamSinh);
            panel_DocGia.Controls.Add(lbNamSinh);
            panel_DocGia.Controls.Add(rbtnNu);
            panel_DocGia.Controls.Add(rbtnNam);
            panel_DocGia.Controls.Add(lbGioiTinh);
            panel_DocGia.Controls.Add(txtHoTen);
            panel_DocGia.Controls.Add(lbHoTen);
            panel_DocGia.Controls.Add(txtTenDangNhap);
            panel_DocGia.Controls.Add(lbTenDangNhap);
            panel_DocGia.Controls.Add(txtMaDocGia);
            panel_DocGia.Controls.Add(lbMaDocGia);
            panel_DocGia.Location = new Point(6, 20);
            panel_DocGia.Name = "panel_DocGia";
            panel_DocGia.Size = new Size(331, 251);
            panel_DocGia.TabIndex = 4;
            // 
            // txtSDT
            // 
            txtSDT.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtSDT.Location = new Point(103, 169);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(207, 20);
            txtSDT.TabIndex = 17;
            // 
            // lblSDT
            // 
            lblSDT.AutoSize = true;
            lblSDT.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblSDT.Location = new Point(2, 172);
            lblSDT.Name = "lblSDT";
            lblSDT.Size = new Size(30, 13);
            lblSDT.TabIndex = 16;
            lblSDT.Text = "SĐT";
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua.Location = new Point(104, 206);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(206, 27);
            btnSua.TabIndex = 15;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // txtMaDocGia
            // 
            txtMaDocGia.Enabled = false;
            txtMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMaDocGia.Location = new Point(104, 8);
            txtMaDocGia.Name = "txtMaDocGia";
            txtMaDocGia.ReadOnly = true;
            txtMaDocGia.Size = new Size(207, 20);
            txtMaDocGia.TabIndex = 1;
            // 
            // FormTaiKhoanUser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(699, 551);
            Controls.Add(panel_DocGia);
            Name = "FormTaiKhoanUser";
            Text = "FormTaiKhoanUser";
            Load += FormTaiKhoanUser_Load;
            panel_DocGia.ResumeLayout(false);
            panel_DocGia.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lbDiaChi;
        private System.Windows.Forms.TextBox txtNamSinh;
        private System.Windows.Forms.Label lbNamSinh;
        private System.Windows.Forms.RadioButton rbtnNu;
        private System.Windows.Forms.RadioButton rbtnNam;
        private System.Windows.Forms.Label lbGioiTinh;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lbHoTen;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.Label lbTenDangNhap;
        private System.Windows.Forms.Label lbMaDocGia;
        private System.Windows.Forms.Panel panel_DocGia;
        private System.Windows.Forms.TextBox txtMaDocGia;
        private System.Windows.Forms.Button btnSua;
        private TextBox txtSDT;
        private Label lblSDT;
    }
}