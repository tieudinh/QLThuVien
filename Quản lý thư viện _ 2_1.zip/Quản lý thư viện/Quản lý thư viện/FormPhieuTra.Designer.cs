﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormPhieuTra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPhieuTra));
            panel_bottom = new FlowLayoutPanel();
            dtGVPhieuTra = new DataGridView();
            gbPhieuMuon = new GroupBox();
            txtMaPhieu = new TextBox();
            lblMaPhieu = new Label();
            btnThem = new Button();
            dTPNgayTra = new DateTimePicker();
            lbNgayTra = new Label();
            cbBook = new ComboBox();
            lbTenSach = new Label();
            cbReader = new ComboBox();
            lbTenDocGia = new Label();
            panel3 = new Panel();
            txtTimKiem = new TextBox();
            btnTimKiem = new Button();
            rbtnTenSach = new RadioButton();
            rbtnNguoiMuon = new RadioButton();
            lbTimKiem = new Label();
            panel_bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtGVPhieuTra).BeginInit();
            gbPhieuMuon.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel_bottom
            // 
            panel_bottom.Controls.Add(dtGVPhieuTra);
            panel_bottom.Location = new Point(10, 232);
            panel_bottom.Name = "panel_bottom";
            panel_bottom.Size = new Size(731, 217);
            panel_bottom.TabIndex = 1;
            // 
            // dtGVPhieuTra
            // 
            dtGVPhieuTra.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtGVPhieuTra.Location = new Point(3, 3);
            dtGVPhieuTra.Name = "dtGVPhieuTra";
            dtGVPhieuTra.RowHeadersWidth = 51;
            dtGVPhieuTra.RowTemplate.Height = 24;
            dtGVPhieuTra.Size = new Size(728, 214);
            dtGVPhieuTra.TabIndex = 0;
            dtGVPhieuTra.RowHeaderMouseClick += dtGVPhieuTra_RowHeaderMouseClick;
            // 
            // gbPhieuMuon
            // 
            gbPhieuMuon.BackColor = SystemColors.ButtonFace;
            gbPhieuMuon.Controls.Add(txtMaPhieu);
            gbPhieuMuon.Controls.Add(lblMaPhieu);
            gbPhieuMuon.Controls.Add(btnThem);
            gbPhieuMuon.Controls.Add(dTPNgayTra);
            gbPhieuMuon.Controls.Add(lbNgayTra);
            gbPhieuMuon.Controls.Add(cbBook);
            gbPhieuMuon.Controls.Add(lbTenSach);
            gbPhieuMuon.Controls.Add(cbReader);
            gbPhieuMuon.Controls.Add(lbTenDocGia);
            gbPhieuMuon.Location = new Point(10, 8);
            gbPhieuMuon.Name = "gbPhieuMuon";
            gbPhieuMuon.Size = new Size(430, 219);
            gbPhieuMuon.TabIndex = 5;
            gbPhieuMuon.TabStop = false;
            // 
            // txtMaPhieu
            // 
            txtMaPhieu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMaPhieu.Location = new Point(132, 19);
            txtMaPhieu.Name = "txtMaPhieu";
            txtMaPhieu.ReadOnly = true;
            txtMaPhieu.Size = new Size(277, 20);
            txtMaPhieu.TabIndex = 24;
            // 
            // lblMaPhieu
            // 
            lblMaPhieu.AutoSize = true;
            lblMaPhieu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblMaPhieu.Location = new Point(21, 22);
            lblMaPhieu.Name = "lblMaPhieu";
            lblMaPhieu.Size = new Size(58, 13);
            lblMaPhieu.TabIndex = 23;
            lblMaPhieu.Text = "Mã phiếu";
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem.Location = new Point(110, 156);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(203, 32);
            btnThem.TabIndex = 13;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // dTPNgayTra
            // 
            dTPNgayTra.CalendarFont = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dTPNgayTra.Location = new Point(132, 113);
            dTPNgayTra.Name = "dTPNgayTra";
            dTPNgayTra.Size = new Size(277, 20);
            dTPNgayTra.TabIndex = 9;
            // 
            // lbNgayTra
            // 
            lbNgayTra.AutoSize = true;
            lbNgayTra.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNgayTra.Location = new Point(21, 119);
            lbNgayTra.Name = "lbNgayTra";
            lbNgayTra.Size = new Size(55, 13);
            lbNgayTra.TabIndex = 8;
            lbNgayTra.Text = "Ngày trả";
            // 
            // cbBook
            // 
            cbBook.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            cbBook.FormattingEnabled = true;
            cbBook.Location = new Point(132, 84);
            cbBook.Name = "cbBook";
            cbBook.Size = new Size(277, 20);
            cbBook.TabIndex = 5;
            // 
            // lbTenSach
            // 
            lbTenSach.AutoSize = true;
            lbTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenSach.Location = new Point(20, 87);
            lbTenSach.Name = "lbTenSach";
            lbTenSach.Size = new Size(57, 13);
            lbTenSach.TabIndex = 4;
            lbTenSach.Text = "Tên sách";
            // 
            // cbReader
            // 
            cbReader.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            cbReader.FormattingEnabled = true;
            cbReader.Location = new Point(132, 52);
            cbReader.Name = "cbReader";
            cbReader.Size = new Size(277, 20);
            cbReader.TabIndex = 3;
            // 
            // lbTenDocGia
            // 
            lbTenDocGia.AutoSize = true;
            lbTenDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenDocGia.Location = new Point(21, 55);
            lbTenDocGia.Name = "lbTenDocGia";
            lbTenDocGia.Size = new Size(75, 13);
            lbTenDocGia.TabIndex = 2;
            lbTenDocGia.Text = "Người mượn";
            // 
            // panel3
            // 
            panel3.Controls.Add(txtTimKiem);
            panel3.Controls.Add(btnTimKiem);
            panel3.Controls.Add(rbtnTenSach);
            panel3.Controls.Add(rbtnNguoiMuon);
            panel3.Controls.Add(lbTimKiem);
            panel3.Location = new Point(447, 8);
            panel3.Name = "panel3";
            panel3.Size = new Size(294, 219);
            panel3.TabIndex = 9;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTimKiem.Location = new Point(41, 52);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(213, 20);
            txtTimKiem.TabIndex = 20;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnTimKiem.Location = new Point(41, 156);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(213, 27);
            btnTimKiem.TabIndex = 21;
            btnTimKiem.Text = "Tìm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // rbtnTenSach
            // 
            rbtnTenSach.AutoSize = true;
            rbtnTenSach.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnTenSach.Location = new Point(56, 118);
            rbtnTenSach.Name = "rbtnTenSach";
            rbtnTenSach.Size = new Size(75, 17);
            rbtnTenSach.TabIndex = 19;
            rbtnTenSach.TabStop = true;
            rbtnTenSach.Text = "Tên sách";
            rbtnTenSach.UseVisualStyleBackColor = true;
            // 
            // rbtnNguoiMuon
            // 
            rbtnNguoiMuon.AutoSize = true;
            rbtnNguoiMuon.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnNguoiMuon.Location = new Point(56, 94);
            rbtnNguoiMuon.Name = "rbtnNguoiMuon";
            rbtnNguoiMuon.Size = new Size(117, 17);
            rbtnNguoiMuon.TabIndex = 18;
            rbtnNguoiMuon.TabStop = true;
            rbtnNguoiMuon.Text = "Tên người mượn";
            rbtnNguoiMuon.UseVisualStyleBackColor = true;
            // 
            // lbTimKiem
            // 
            lbTimKiem.AutoSize = true;
            lbTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTimKiem.Location = new Point(3, 22);
            lbTimKiem.Name = "lbTimKiem";
            lbTimKiem.Size = new Size(88, 13);
            lbTimKiem.TabIndex = 17;
            lbTimKiem.Text = "Tìm kiếm theo";
            // 
            // FormPhieuTra
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(752, 458);
            Controls.Add(panel3);
            Controls.Add(gbPhieuMuon);
            Controls.Add(panel_bottom);
            Name = "FormPhieuTra";
            Text = "FormPhieuTra";
            Load += FormPhieuTra_Load;
            panel_bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtGVPhieuTra).EndInit();
            gbPhieuMuon.ResumeLayout(false);
            gbPhieuMuon.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel panel_bottom;
        private System.Windows.Forms.GroupBox gbPhieuMuon;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DateTimePicker dTPNgayTra;
        private System.Windows.Forms.Label lbNgayTra;
        private System.Windows.Forms.ComboBox cbBook;
        private System.Windows.Forms.Label lbTenSach;
        private System.Windows.Forms.ComboBox cbReader;
        private System.Windows.Forms.Label lbTenDocGia;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.RadioButton rbtnTenSach;
        private System.Windows.Forms.RadioButton rbtnNguoiMuon;
        private System.Windows.Forms.Label lbTimKiem;
        private System.Windows.Forms.DataGridView dtGVPhieuTra;
        private TextBox txtMaPhieu;
        private Label lblMaPhieu;
    }
}