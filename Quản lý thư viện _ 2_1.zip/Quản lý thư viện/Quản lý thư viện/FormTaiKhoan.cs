﻿using QLTV_BUS;
using QLTV_DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCuoiKi_LTWin
{
    public partial class FormTaiKhoan : Form
    {
        public FormTaiKhoan()
        {
            InitializeComponent();
        }

        private void displayList()
        {
            dtGVTK.DataSource = TaiKhoan_BUS.layDSTaiKhoan();
        }

        private void FormTaiKhoan_Load(object sender, EventArgs e)
        {
            displayList();
        }

        private void dtGVTK_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtMaDocGia.Text = dtGVTK.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtTenDangNhap.Text = dtGVTK.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtMatKhau.Text = dtGVTK.Rows[e.RowIndex].Cells[2].Value.ToString();

            //txtVaiTro.Text = dtGVTK.Rows[e.RowIndex].Cells[3].Value.ToString();
            if (int.Parse(dtGVTK.Rows[e.RowIndex].Cells[3].Value.ToString()) == 1)
                txtVaiTro.Text = "Admin";
            else if (int.Parse(dtGVTK.Rows[e.RowIndex].Cells[3].Value.ToString()) == 0)
                txtVaiTro.Text = "Độc giả";
        }

        private void btnTimKiemTK_Click(object sender, EventArgs e)
        {
            if (rbtnMaDocGia.Checked == true)
                dtGVTK.DataSource = TaiKhoan_BUS.timKiemDG_MaDocGia(txtTimKiem.Text);
            else if (rbtnTenDangNhap.Checked == true)
                dtGVTK.DataSource = TaiKhoan_BUS.timKiemDG_TenDangNhap(txtTimKiem.Text);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                Class_TaiKhoan tk = new Class_TaiKhoan();

                tk.MaDocGia = txtMaDocGia.Text;
                tk.TenDangNhap = txtTenDangNhap.Text;
                tk.MatKhau = txtMatKhau.Text;
                tk.VaiTro = int.Parse(txtVaiTro.Text);

                TaiKhoan_BUS.suaTK(tk);

                MessageBox.Show("Sửa thông tin tài khoản thành công!", "Thông báo", MessageBoxButtons.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
