﻿namespace DoAnCuoiKi_LTWin
{
    partial class FormDocGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDocGia));
            panel_bottom = new FlowLayoutPanel();
            dgvDocGia = new DataGridView();
            panel_DocGia = new Panel();
            txtSDT = new TextBox();
            lblSDT = new Label();
            btnSua = new Button();
            btnXoa = new Button();
            btnThem = new Button();
            txtDiaChi = new TextBox();
            lbDiaChi = new Label();
            txtNamSinh = new TextBox();
            lbNamSinh = new Label();
            rbtnNu = new RadioButton();
            rbtnNam = new RadioButton();
            lbGioiTinh = new Label();
            txtHoTen = new TextBox();
            lbHoTen = new Label();
            txtTenDangNhap = new TextBox();
            lbTenDangNhap = new Label();
            txtMaDocGia = new TextBox();
            lbMaDocGia = new Label();
            panel_TimKiem = new Panel();
            rbtnHoTen = new RadioButton();
            rbtnTenDangNhap = new RadioButton();
            rbtnMaDocGia = new RadioButton();
            txtTimKiem = new TextBox();
            btnTimKiem = new Button();
            lbTimKiem = new Label();
            panel_bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDocGia).BeginInit();
            panel_DocGia.SuspendLayout();
            panel_TimKiem.SuspendLayout();
            SuspendLayout();
            // 
            // panel_bottom
            // 
            panel_bottom.Controls.Add(dgvDocGia);
            panel_bottom.Location = new Point(10, 271);
            panel_bottom.Name = "panel_bottom";
            panel_bottom.Size = new Size(590, 217);
            panel_bottom.TabIndex = 0;
            // 
            // dgvDocGia
            // 
            dgvDocGia.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDocGia.Location = new Point(3, 3);
            dgvDocGia.Name = "dgvDocGia";
            dgvDocGia.Size = new Size(587, 210);
            dgvDocGia.TabIndex = 0;
            dgvDocGia.RowHeaderMouseClick += dgvDocGia_RowHeaderMouseClick;
            // 
            // panel_DocGia
            // 
            panel_DocGia.Controls.Add(txtSDT);
            panel_DocGia.Controls.Add(lblSDT);
            panel_DocGia.Controls.Add(btnSua);
            panel_DocGia.Controls.Add(btnXoa);
            panel_DocGia.Controls.Add(btnThem);
            panel_DocGia.Controls.Add(txtDiaChi);
            panel_DocGia.Controls.Add(lbDiaChi);
            panel_DocGia.Controls.Add(txtNamSinh);
            panel_DocGia.Controls.Add(lbNamSinh);
            panel_DocGia.Controls.Add(rbtnNu);
            panel_DocGia.Controls.Add(rbtnNam);
            panel_DocGia.Controls.Add(lbGioiTinh);
            panel_DocGia.Controls.Add(txtHoTen);
            panel_DocGia.Controls.Add(lbHoTen);
            panel_DocGia.Controls.Add(txtTenDangNhap);
            panel_DocGia.Controls.Add(lbTenDangNhap);
            panel_DocGia.Controls.Add(txtMaDocGia);
            panel_DocGia.Controls.Add(lbMaDocGia);
            panel_DocGia.Location = new Point(10, 11);
            panel_DocGia.Name = "panel_DocGia";
            panel_DocGia.Size = new Size(318, 254);
            panel_DocGia.TabIndex = 1;
            // 
            // txtSDT
            // 
            txtSDT.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtSDT.Location = new Point(104, 169);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(207, 20);
            txtSDT.TabIndex = 17;
            // 
            // lblSDT
            // 
            lblSDT.AutoSize = true;
            lblSDT.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblSDT.Location = new Point(3, 172);
            lblSDT.Name = "lblSDT";
            lblSDT.Size = new Size(30, 13);
            lblSDT.TabIndex = 16;
            lblSDT.Text = "SĐT";
            // 
            // btnSua
            // 
            btnSua.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua.Location = new Point(224, 218);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(87, 27);
            btnSua.TabIndex = 15;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = true;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa.Location = new Point(116, 218);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(87, 27);
            btnXoa.TabIndex = 14;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnThem
            // 
            btnThem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem.Location = new Point(5, 218);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(87, 27);
            btnThem.TabIndex = 13;
            btnThem.Text = "Thêm";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // txtDiaChi
            // 
            txtDiaChi.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtDiaChi.Location = new Point(104, 143);
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(207, 20);
            txtDiaChi.TabIndex = 12;
            // 
            // lbDiaChi
            // 
            lbDiaChi.AutoSize = true;
            lbDiaChi.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbDiaChi.Location = new Point(3, 146);
            lbDiaChi.Name = "lbDiaChi";
            lbDiaChi.Size = new Size(45, 13);
            lbDiaChi.TabIndex = 11;
            lbDiaChi.Text = "Địa chỉ";
            // 
            // txtNamSinh
            // 
            txtNamSinh.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtNamSinh.Location = new Point(104, 116);
            txtNamSinh.Name = "txtNamSinh";
            txtNamSinh.Size = new Size(207, 20);
            txtNamSinh.TabIndex = 10;
            // 
            // lbNamSinh
            // 
            lbNamSinh.AutoSize = true;
            lbNamSinh.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbNamSinh.Location = new Point(3, 119);
            lbNamSinh.Name = "lbNamSinh";
            lbNamSinh.Size = new Size(58, 13);
            lbNamSinh.TabIndex = 9;
            lbNamSinh.Text = "Năm sinh";
            // 
            // rbtnNu
            // 
            rbtnNu.AutoSize = true;
            rbtnNu.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnNu.Location = new Point(271, 92);
            rbtnNu.Name = "rbtnNu";
            rbtnNu.Size = new Size(40, 17);
            rbtnNu.TabIndex = 8;
            rbtnNu.TabStop = true;
            rbtnNu.Text = "Nữ";
            rbtnNu.UseVisualStyleBackColor = true;
            // 
            // rbtnNam
            // 
            rbtnNam.AutoSize = true;
            rbtnNam.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            rbtnNam.Location = new Point(104, 92);
            rbtnNam.Name = "rbtnNam";
            rbtnNam.Size = new Size(50, 17);
            rbtnNam.TabIndex = 7;
            rbtnNam.TabStop = true;
            rbtnNam.Text = "Nam";
            rbtnNam.UseVisualStyleBackColor = true;
            // 
            // lbGioiTinh
            // 
            lbGioiTinh.AutoSize = true;
            lbGioiTinh.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbGioiTinh.Location = new Point(3, 92);
            lbGioiTinh.Name = "lbGioiTinh";
            lbGioiTinh.Size = new Size(53, 13);
            lbGioiTinh.TabIndex = 6;
            lbGioiTinh.Text = "Giới tính";
            // 
            // txtHoTen
            // 
            txtHoTen.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtHoTen.Location = new Point(104, 62);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(207, 20);
            txtHoTen.TabIndex = 5;
            // 
            // lbHoTen
            // 
            lbHoTen.AutoSize = true;
            lbHoTen.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbHoTen.Location = new Point(3, 65);
            lbHoTen.Name = "lbHoTen";
            lbHoTen.Size = new Size(44, 13);
            lbHoTen.TabIndex = 4;
            lbHoTen.Text = "Họ tên";
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTenDangNhap.Location = new Point(104, 35);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.Size = new Size(207, 20);
            txtTenDangNhap.TabIndex = 3;
            // 
            // lbTenDangNhap
            // 
            lbTenDangNhap.AutoSize = true;
            lbTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTenDangNhap.Location = new Point(3, 38);
            lbTenDangNhap.Name = "lbTenDangNhap";
            lbTenDangNhap.Size = new Size(90, 13);
            lbTenDangNhap.TabIndex = 2;
            lbTenDangNhap.Text = "Tên đăng nhập";
            // 
            // txtMaDocGia
            // 
            txtMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtMaDocGia.Location = new Point(104, 8);
            txtMaDocGia.Name = "txtMaDocGia";
            txtMaDocGia.ReadOnly = true;
            txtMaDocGia.RightToLeft = RightToLeft.No;
            txtMaDocGia.Size = new Size(207, 20);
            txtMaDocGia.TabIndex = 1;
            // 
            // lbMaDocGia
            // 
            lbMaDocGia.AutoSize = true;
            lbMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbMaDocGia.Location = new Point(3, 10);
            lbMaDocGia.Name = "lbMaDocGia";
            lbMaDocGia.Size = new Size(67, 13);
            lbMaDocGia.TabIndex = 0;
            lbMaDocGia.Text = "Mã độc giả";
            // 
            // panel_TimKiem
            // 
            panel_TimKiem.Controls.Add(rbtnHoTen);
            panel_TimKiem.Controls.Add(rbtnTenDangNhap);
            panel_TimKiem.Controls.Add(rbtnMaDocGia);
            panel_TimKiem.Controls.Add(txtTimKiem);
            panel_TimKiem.Controls.Add(btnTimKiem);
            panel_TimKiem.Controls.Add(lbTimKiem);
            panel_TimKiem.Location = new Point(333, 11);
            panel_TimKiem.Name = "panel_TimKiem";
            panel_TimKiem.Size = new Size(267, 254);
            panel_TimKiem.TabIndex = 2;
            // 
            // rbtnHoTen
            // 
            rbtnHoTen.AutoSize = true;
            rbtnHoTen.Font = new Font("Tahoma", 7.8F, FontStyle.Bold);
            rbtnHoTen.Location = new Point(32, 168);
            rbtnHoTen.Name = "rbtnHoTen";
            rbtnHoTen.Size = new Size(62, 17);
            rbtnHoTen.TabIndex = 19;
            rbtnHoTen.TabStop = true;
            rbtnHoTen.Text = "Họ tên";
            rbtnHoTen.UseVisualStyleBackColor = true;
            // 
            // rbtnTenDangNhap
            // 
            rbtnTenDangNhap.AutoSize = true;
            rbtnTenDangNhap.Font = new Font("Tahoma", 7.8F, FontStyle.Bold);
            rbtnTenDangNhap.Location = new Point(32, 131);
            rbtnTenDangNhap.Name = "rbtnTenDangNhap";
            rbtnTenDangNhap.Size = new Size(108, 17);
            rbtnTenDangNhap.TabIndex = 18;
            rbtnTenDangNhap.TabStop = true;
            rbtnTenDangNhap.Text = "Tên đăng nhập";
            rbtnTenDangNhap.UseVisualStyleBackColor = true;
            // 
            // rbtnMaDocGia
            // 
            rbtnMaDocGia.AutoSize = true;
            rbtnMaDocGia.Font = new Font("Tahoma", 7.8F, FontStyle.Bold);
            rbtnMaDocGia.Location = new Point(32, 90);
            rbtnMaDocGia.Name = "rbtnMaDocGia";
            rbtnMaDocGia.Size = new Size(85, 17);
            rbtnMaDocGia.TabIndex = 17;
            rbtnMaDocGia.TabStop = true;
            rbtnMaDocGia.Text = "Mã độc giả";
            rbtnMaDocGia.UseVisualStyleBackColor = true;
            // 
            // txtTimKiem
            // 
            txtTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            txtTimKiem.Location = new Point(32, 35);
            txtTimKiem.Name = "txtTimKiem";
            txtTimKiem.Size = new Size(213, 20);
            txtTimKiem.TabIndex = 16;
            // 
            // btnTimKiem
            // 
            btnTimKiem.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnTimKiem.Location = new Point(32, 218);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.Size = new Size(213, 27);
            btnTimKiem.TabIndex = 16;
            btnTimKiem.Text = "Tìm";
            btnTimKiem.UseVisualStyleBackColor = true;
            btnTimKiem.Click += btnTimKiem_Click;
            // 
            // lbTimKiem
            // 
            lbTimKiem.AutoSize = true;
            lbTimKiem.Font = new Font("Tahoma", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lbTimKiem.Location = new Point(3, 10);
            lbTimKiem.Name = "lbTimKiem";
            lbTimKiem.Size = new Size(102, 13);
            lbTimKiem.TabIndex = 16;
            lbTimKiem.Text = "Tìm kiếm độc giả";
            // 
            // FormDocGia
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(700, 499);
            Controls.Add(panel_TimKiem);
            Controls.Add(panel_DocGia);
            Controls.Add(panel_bottom);
            Name = "FormDocGia";
            Text = "FormDocGia";
            Load += FormDocGia_Load;
            panel_bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvDocGia).EndInit();
            panel_DocGia.ResumeLayout(false);
            panel_DocGia.PerformLayout();
            panel_TimKiem.ResumeLayout(false);
            panel_TimKiem.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel panel_bottom;
        private System.Windows.Forms.Panel panel_DocGia;
        private System.Windows.Forms.RadioButton rbtnNam;
        private System.Windows.Forms.Label lbGioiTinh;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lbHoTen;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.Label lbTenDangNhap;
        private System.Windows.Forms.TextBox txtMaDocGia;
        private System.Windows.Forms.Label lbMaDocGia;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lbDiaChi;
        private System.Windows.Forms.TextBox txtNamSinh;
        private System.Windows.Forms.Label lbNamSinh;
        private System.Windows.Forms.RadioButton rbtnNu;
        private System.Windows.Forms.Panel panel_TimKiem;
        private System.Windows.Forms.Label lbTimKiem;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.DataGridView dgvDocGia;
        private TextBox txtSDT;
        private Label lblSDT;
        private RadioButton rbtnHoTen;
        private RadioButton rbtnTenDangNhap;
        private RadioButton rbtnMaDocGia;
    }
}